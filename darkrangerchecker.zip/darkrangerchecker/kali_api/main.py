import asyncio
import logging
import os
from typing import Optional
from urllib.parse import urlparse

import aiohttp
from aiohttp import web

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

API_HOST = os.environ.get("KALI_API_HOST", "127.0.0.1")
API_PORT = int(os.environ.get("KALI_API_PORT", "8090"))
API_KEY = os.environ.get("KALI_API_KEY", "ladle")
REQUEST_TIMEOUT = float(os.environ.get("KALI_API_TIMEOUT", "25"))


def _normalize_proxy(proxy: str) -> Optional[str]:
    if not proxy:
        return None
    p = proxy.strip()
    if not p:
        return None
    if p.startswith(("http://", "https://", "socks5://", "socks4://")):
        return p
    parts = p.split()
    if len(parts) == 4:
        user, pwd, host, port = parts
        return f"http://{user}:{pwd}@{host}:{port}"
    return f"http://{p}"


def _normalize_site(site: str) -> Optional[str]:
    if not site:
        return None
    s = site.strip()
    if not s:
        return None
    if not s.startswith(("http://", "https://")):
        s = "https://" + s
    parsed = urlparse(s)
    if not parsed.netloc:
        return None
    return f"{parsed.scheme}://{parsed.netloc}"


async def _check_proxy_and_site(base_url: str, proxy_url: Optional[str]) -> tuple[str, str, Optional[str]]:
    """
    Checks connectivity through the proxy (or directly if no proxy is provided)
    against the target site / products endpoint so msh.py gets real status feedback.
    """
    probe_url = f"{base_url}/products.json?limit=1"
    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT, connect=10)
    connector = aiohttp.TCPConnector(ssl=False)

    try:
        async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
            async with session.get(probe_url, proxy=proxy_url) as resp:
                proxy_state = "Live" if proxy_url else "Direct"
                if resp.status == 429:
                    return "false", "429 Too Many Requests", proxy_state
                if resp.status >= 500:
                    return "false", f"Server Error: HTTP {resp.status}", proxy_state
                if resp.status in (401, 403):
                    return "false", f"Site Error! Status: {resp.status}", proxy_state
                if resp.status == 404:
                    return "false", "Not Shopify! / products.json not found", proxy_state
                if resp.status == 200:
                    try:
                        data = await resp.json(content_type=None)
                        products = data.get("products") if isinstance(data, dict) else None
                        if not products:
                            return "false", "No available products found", proxy_state
                        return "false", "CARD_DECLINED", proxy_state
                    except Exception:
                        return "false", "Invalid JSON from store", proxy_state
                return "false", f"HTTP {resp.status}", proxy_state
    except asyncio.TimeoutError:
        return "false", "Connection Timeout", "Dead" if proxy_url else "Error"
    except aiohttp.ClientProxyConnectionError as e:
        return "false", f"Proxy Connection Error: {e}", "Dead"
    except aiohttp.ClientError as e:
        return "false", f"Connection Error: {e}", "Dead" if proxy_url else "Error"
    except Exception as e:
        return "false", f"Error: {e}", "Dead" if proxy_url else "Error"


async def health_handler(request: web.Request) -> web.Response:
    return web.json_response({"ok": True, "service": "kali_api", "port": API_PORT})


async def shopii_handler(request: web.Request) -> web.Response:
    cc = (request.query.get("cc") or "").strip()
    site_raw = (request.query.get("site") or "").strip()
    proxy_raw = (request.query.get("proxy") or "").strip()
    key = (request.query.get("key") or "").strip()

    if key != API_KEY:
        return web.json_response(
            {
                "Status": "false",
                "Response": "Invalid API Key",
                "Gateway": "Shopify Payments",
                "Price": "0.00",
                "Proxy": "Dead",
            },
            status=401,
        )

    if not cc or not site_raw:
        return web.json_response(
            {
                "Status": "false",
                "Response": "Missing cc or site",
                "Gateway": "Shopify Payments",
                "Price": "0.00",
                "Proxy": "Dead",
            },
            status=400,
        )

    base_url = _normalize_site(site_raw)
    if not base_url:
        return web.json_response(
            {
                "Status": "false",
                "Response": "Invalid site URL",
                "Gateway": "Shopify Payments",
                "Price": "0.00",
                "Proxy": "Dead",
            },
            status=400,
        )

    proxy_url = _normalize_proxy(proxy_raw)
    status_str, response_msg, proxy_state = await _check_proxy_and_site(base_url, proxy_url)

    logging.info(f"CC={cc[:6]}*** | SITE={base_url} | PROXY_STATE={proxy_state} | RESP={response_msg}")

    return web.json_response(
        {
            "Status": status_str,
            "Response": response_msg,
            "Gateway": "Shopify Payments",
            "Price": "0.00",
            "Proxy": proxy_state,
        }
    )


def create_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/health", health_handler)
    app.router.add_get("/shopii", shopii_handler)
    return app


if __name__ == "__main__":
    logging.info(f"Starting kali_api server on http://{API_HOST}:{API_PORT}/shopii")
    web.run_app(create_app(), host=API_HOST, port=API_PORT)
