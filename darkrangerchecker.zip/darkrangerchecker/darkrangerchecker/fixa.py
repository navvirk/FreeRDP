import os

OLD_ID = "8909940627"
NEW_ID = "8909940627"   # minus hata diya, positive ID

files_changed = []
skipped = []

for root, dirs, files in os.walk("."):
    if any(x in root for x in ["psycopg2", "__pycache__", ".git", "node_modules"]):
        continue
    for file in files:
        if not file.endswith(".py"):
            continue
        if file.startswith("fix_") or file.startswith("setup_"):
            skipped.append(file)
            continue

        path = os.path.join(root, file)
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            continue

        if OLD_ID not in content:
            continue

        new_content = content.replace(OLD_ID, NEW_ID)

        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        files_changed.append(path)

print(f"✅ Replaced {OLD_ID} → {NEW_ID} in {len(files_changed)} files:")
for f in files_changed:
    print(f"   - {f}")

if skipped:
    print(f"\n⏭  Skipped (fix/setup scripts): {skipped}")