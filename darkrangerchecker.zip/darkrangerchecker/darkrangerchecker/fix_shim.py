# fix_shim.py
import re

path = "psycopg2/__init__.py"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

# Remove the top `from . import extras, pool` line (with any trailing comment)
content = re.sub(
    r"^from \. import extras, pool.*\n",
    "",
    content,
    count=1,
    flags=re.MULTILINE,
)

# Append it at the very bottom so connect/Error are already defined
if not content.rstrip().endswith("from . import extras, pool  # noqa: F401"):
    content = content.rstrip() + "\n\n\n# Deferred imports (avoid circular import)\nfrom . import extras, pool  # noqa: F401\n"

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

print("✅ Fixed circular import in psycopg2/__init__.py")