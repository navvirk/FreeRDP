"""psycopg2 compatibility shim — mimics psycopg2 API using SQLite."""
import sqlite3
import os
import re

from . import extras, pool  # noqa: F401

__version__ = "2.9.9-sqlite-shim"

DB_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "wizard.db"
)


# ── Exception aliases ──
class Error(Exception): pass
class Warning(Exception): pass
class InterfaceError(Error): pass
class DatabaseError(Error): pass
class DataError(DatabaseError): pass
class OperationalError(DatabaseError): pass
class IntegrityError(DatabaseError): pass
class InternalError(DatabaseError): pass
class ProgrammingError(DatabaseError): pass
class NotSupportedError(DatabaseError): pass


def _rewrite_sql(sql: str) -> str:
    """Translate Postgres-flavoured SQL to SQLite-compatible SQL."""
    # Placeholders
    sql = sql.replace("%s", "?")

    # ALTER TABLE ... ADD COLUMN IF NOT EXISTS → ADD COLUMN
    sql = re.sub(
        r"(ALTER\s+TABLE\s+[\w\.\"`\[\]]+\s+ADD\s+COLUMN)\s+IF\s+NOT\s+EXISTS\s+",
        r"\1 ",
        sql,
        flags=re.IGNORECASE,
    )

    # GREATEST/LEAST → MAX/MIN (SQLite scalar)
    sql = re.sub(r"\bGREATEST\s*\(", "MAX(", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bLEAST\s*\(", "MIN(", sql, flags=re.IGNORECASE)

    # NOW() → CURRENT_TIMESTAMP
    sql = re.sub(r"\bNOW\s*\(\s*\)", "CURRENT_TIMESTAMP", sql, flags=re.IGNORECASE)

    # CAST shortcut: x::int → CAST(x AS INTEGER) — basic form
    sql = re.sub(r"(\w+|\))\:\:(int|integer|bigint)\b", r"CAST(\1 AS INTEGER)", sql, flags=re.IGNORECASE)
    sql = re.sub(r"(\w+|\))\:\:(text|varchar)\b", r"CAST(\1 AS TEXT)", sql, flags=re.IGNORECASE)
    sql = re.sub(r"(\w+|\))\:\:(bool|boolean)\b", r"CAST(\1 AS INTEGER)", sql, flags=re.IGNORECASE)

    # SERIAL / BIGSERIAL
    sql = re.sub(
        r"\b(?:BIG)?SERIAL\s+PRIMARY\s+KEY\b",
        "INTEGER PRIMARY KEY AUTOINCREMENT",
        sql,
        flags=re.IGNORECASE,
    )
    sql = re.sub(r"\b(?:BIG)?SERIAL\b", "INTEGER", sql, flags=re.IGNORECASE)

    # Type aliases
    sql = re.sub(r"\bBIGINT\b", "INTEGER", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bBOOLEAN\b", "INTEGER", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bBYTEA\b", "BLOB", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bDOUBLE\s+PRECISION\b", "REAL", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\btimestamp\s+with\s+time\s+zone\b", "TIMESTAMP", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\btimestamptz\b", "TIMESTAMP", sql, flags=re.IGNORECASE)

    # DEFAULT TRUE/FALSE
    sql = re.sub(r"\bDEFAULT\s+TRUE\b", "DEFAULT 1", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bDEFAULT\s+FALSE\b", "DEFAULT 0", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bDEFAULT\s+NOW\s*\(\s*\)", "DEFAULT CURRENT_TIMESTAMP", sql, flags=re.IGNORECASE)

    # ILIKE → LIKE (SQLite LIKE is case-insensitive by default)
    sql = re.sub(r"\bILIKE\b", "LIKE", sql, flags=re.IGNORECASE)

    # FOR UPDATE — SQLite doesn't need/have it, strip
    sql = re.sub(r"\bFOR\s+UPDATE\b", "", sql, flags=re.IGNORECASE)

    return sql


class _Cursor:
    def __init__(self, conn, cursor_factory=None):
        self._conn = conn
        self._sqlite_conn = conn._sqlite_conn
        self._row_factory = cursor_factory or conn.cursor_factory
        if self._row_factory is not None:
            self._sqlite_conn.row_factory = sqlite3.Row
        else:
            self._sqlite_conn.row_factory = None
        self._cursor = self._sqlite_conn.cursor()
        self.closed = False

    def _convert(self, row):
        if row is None:
            return None
        if self._row_factory is extras.RealDictCursor:
            return dict(row) if not isinstance(row, dict) else row
        if isinstance(row, sqlite3.Row):
            return tuple(row)
        return row

    def execute(self, sql, params=None):
        sql = _rewrite_sql(sql)
        try:
            if params is None:
                self._cursor.execute(sql)
            else:
                self._cursor.execute(sql, tuple(params))
        except sqlite3.OperationalError as e:
            msg = str(e).lower()
            if "duplicate column name" in msg:
                return
            raise OperationalError(str(e)) from e
        except sqlite3.IntegrityError as e:
            raise IntegrityError(str(e)) from e
        except sqlite3.ProgrammingError as e:
            raise ProgrammingError(str(e)) from e
        except sqlite3.Error as e:
            raise DatabaseError(str(e)) from e

    def executemany(self, sql, params_list):
        sql = _rewrite_sql(sql)
        try:
            self._cursor.executemany(sql, [tuple(p) for p in params_list])
        except sqlite3.Error as e:
            raise DatabaseError(str(e)) from e

    def fetchone(self):
        return self._convert(self._cursor.fetchone())

    def fetchall(self):
        return [self._convert(r) for r in self._cursor.fetchall()]

    def fetchmany(self, size=None):
        rows = self._cursor.fetchmany(size) if size else self._cursor.fetchmany()
        return [self._convert(r) for r in rows]

    @property
    def description(self):
        return self._cursor.description

    @property
    def rowcount(self):
        return self._cursor.rowcount

    @property
    def lastrowid(self):
        return self._cursor.lastrowid

    def close(self):
        if not self.closed:
            try: self._cursor.close()
            except Exception: pass
            self.closed = True

    def __iter__(self):
        for row in self._cursor:
            yield self._convert(row)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
        return False


class _Connection:
    def __init__(self, sqlite_conn):
        self._sqlite_conn = sqlite_conn
        self.cursor_factory = None
        self.closed = False
        self.autocommit = False

    def cursor(self, cursor_factory=None):
        return _Cursor(self, cursor_factory=cursor_factory)

    def commit(self):
        self._sqlite_conn.commit()

    def rollback(self):
        try: self._sqlite_conn.rollback()
        except Exception: pass

    def close(self):
        if not self.closed:
            try: self._sqlite_conn.close()
            except Exception: pass
            self.closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *_):
        if exc_type:
            self.rollback()
        else:
            self.commit()
        self.close()
        return False


def _resolve_db_path(kwargs):
    db = kwargs.get("database") or kwargs.get("dbname") or ""
    if db and (os.sep in db or "/" in db) and db.endswith(".db"):
        return db
    return DB_PATH


def connect(**kwargs):
    path = _resolve_db_path(kwargs)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = sqlite3.connect(path, timeout=10, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    conn.execute("PRAGMA foreign_keys=ON")
    wrapper = _Connection(conn)
    wrapper.cursor_factory = kwargs.get("cursor_factory")
    return wrapper


connect_ex = connect