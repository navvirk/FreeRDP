import os

NEW_DATABASE = r'''import os
import sqlite3
import threading
import time
import logging

from psycopg2 import _Connection as _ShimConnection
from psycopg2.extras import RealDictCursor

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wizard.db")

DB_CONFIG = {
    "database": DB_PATH,
    "host": "localhost",
    "port": 5432,
    "user": "",
    "password": "",
}


def _get_raw_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    conn.execute("PRAGMA foreign_keys=ON")
    return _ShimConnection(conn)


class _AutoReturnConn:
    __slots__ = ('_conn',)

    def __init__(self, conn):
        object.__setattr__(self, '_conn', conn)

    def cursor(self, cursor_factory=None, **_kwargs):
        return self._conn.cursor(cursor_factory=cursor_factory)

    def __getattr__(self, name):
        return getattr(self._conn, name)

    def __setattr__(self, name, value):
        setattr(self._conn, name, value)

    def close(self):
        try:
            self._conn.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
        return False


def _release(conn):
    if isinstance(conn, _AutoReturnConn):
        conn = conn._conn
    try:
        conn.close()
    except Exception as e:
        logging.warning(f"[DB] close error: {e}")


def get_db_connection():
    return _AutoReturnConn(_get_raw_connection())


class PooledConn:
    def __init__(self):
        self.conn = None

    def __enter__(self):
        self.conn = _AutoReturnConn(_get_raw_connection())
        return self.conn

    def __exit__(self, exc_type, *_):
        if self.conn:
            if exc_type:
                try:
                    self.conn.rollback()
                except Exception:
                    pass
            self.conn.close()
        return False


_gate_cache = {}
_gate_cache_ttl = 30
_credits_cache = {}
_credits_cache_ttl = 5
_premium_cache = {}
_premium_cache_ttl = 60

OWNER_IDS = {8462705169}
UNLIMITED_CREDITS = 999_999_999
_owner_cache = {}
_owner_cache_ttl = 60


def is_owner_user(user_id):
    if user_id in OWNER_IDS:
        return True
    now = time.monotonic()
    cached = _owner_cache.get(user_id)
    if cached is not None and now < cached[1]:
        return cached[0]
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT is_owner FROM users WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
            val = bool(row and row[0])
    except Exception:
        val = False
    _owner_cache[user_id] = (val, now + _owner_cache_ttl)
    return val


def has_rz_access(user_id):
    if user_id in OWNER_IDS:
        return True
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT rz_access FROM users WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
            return bool(row and row[0])
    except Exception:
        return False


def set_rz_access(user_id, val):
    if user_id in OWNER_IDS and val == 0:
        return
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            try:
                cur.execute("ALTER TABLE users ADD COLUMN rz_access INTEGER DEFAULT 0")
            except Exception:
                pass
            cur.execute("UPDATE users SET rz_access = ? WHERE user_id = ?", (val, user_id))
            conn.commit()
    except Exception:
        pass


def set_owner_flag(user_id, val):
    with PooledConn() as conn:
        cur = conn.cursor()
        try:
            cur.execute("ALTER TABLE users ADD COLUMN is_owner INTEGER DEFAULT 0")
        except Exception:
            pass
        cur.execute(
            "INSERT INTO users (user_id, credits, joined_at, is_owner) "
            "VALUES (?, 0, CURRENT_TIMESTAMP, ?) "
            "ON CONFLICT (user_id) DO UPDATE SET is_owner = excluded.is_owner",
            (user_id, val),
        )
        conn.commit()
    _owner_cache[user_id] = (bool(val), time.monotonic() + _owner_cache_ttl)


def ensure_users_table():
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    credits INTEGER DEFAULT 0,
                    cc_checked INTEGER DEFAULT 0,
                    cc_charged INTEGER DEFAULT 0,
                    joined_at TIMESTAMP
                )
            """)
            conn.commit()
        print("[DB] Users table checked.")
    except Exception as e:
        print(f"[DB] Error ensuring users table: {e}")


def ensure_stats_columns():
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            for stmt in (
                "ALTER TABLE users ADD COLUMN cc_checked INTEGER DEFAULT 0",
                "ALTER TABLE users ADD COLUMN cc_charged INTEGER DEFAULT 0",
                "ALTER TABLE users ADD COLUMN is_owner INTEGER DEFAULT 0",
                "ALTER TABLE users ADD COLUMN rz_access INTEGER DEFAULT 0",
                "ALTER TABLE users ADD COLUMN first_name TEXT",
                "ALTER TABLE users ADD COLUMN is_premium INTEGER DEFAULT 0",
                "ALTER TABLE users ADD COLUMN premium_expiry TIMESTAMP",
            ):
                try:
                    cur.execute(stmt)
                    conn.commit()
                except Exception:
                    pass
        print("[DB] Stats columns checked/created.")
    except Exception as e:
        print(f"[DB] Error checking stats columns: {e}")


def ensure_proxy_table():
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS proxies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    proxy TEXT NOT NULL,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
        print("[DB] Proxies table checked/created.")
    except Exception as e:
        print(f"[DB] Error creating proxies table: {e}")


def ensure_gate_table():
    try:
        with PooledConn() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS gate_status (
                    gate TEXT PRIMARY KEY,
                    is_enabled INTEGER DEFAULT 1,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
        print("[DB] Gate status table checked.")
    except Exception as e:
        print(f"[DB] Error creating gate table: {e}")


def get_user(user_id):
    with PooledConn() as conn:
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        return dict(row) if row else None


def create_user(user_id, username):
    with PooledConn() as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (user_id, username, credits, joined_at) "
            "VALUES (?, ?, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT (user_id) DO NOTHING",
            (user_id, username, 150),
        )
        conn.commit()


def get_user_credits(user_id):
    return UNLIMITED_CREDITS


def update_credits(user_id, new_credits):
    if is_owner_user(user_id):
        return
    with PooledConn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET credits = ? WHERE user_id = ?", (new_credits, user_id))
        conn.commit()
    _credits_cache[user_id] = (new_credits, time.monotonic() + _credits_cache_ttl)


def deduct_credits_atomic(user_id, amount):
    if is_owner_user(user_id):
        return UNLIMITED_CREDITS
    with PooledConn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET credits = MAX(credits - ?, 0) WHERE user_id = ?", (amount, user_id))
        cur.execute("SELECT credits FROM users WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        conn.commit()
        new_credits = row[0] if row else 0
    _credits_cache[user_id] = (new_credits, time.monotonic() + _credits_cache_ttl)
    return new_credits


def update_user_stats(user_id, is_charged):
    with PooledConn() as conn:
        cur = conn.cursor()
        if is_charged:
            cur.execute(
                "UPDATE users SET cc_checked = cc_checked + 1, cc_charged = cc_charged + 1 WHERE user_id = ?",
                (user_id,),
            )
        else:
            cur.execute("UPDATE users SET cc_checked = cc_checked + 1 WHERE user_id = ?", (user_id,))
        conn.commit()


def is_gate_enabled(gate):
    now = time.monotonic()
    cached = _gate_cache.get(gate)
    if cached and now < cached[1]:
        return cached[0]
    with PooledConn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO gate_status (gate, is_enabled) VALUES (?, 1) ON CONFLICT (gate) DO NOTHING", (gate,))
        cur.execute("SELECT is_enabled FROM gate_status WHERE gate = ?", (gate,))
        row = cur.fetchone()
        conn.commit()
        status = bool(row[0]) if row else True
    _gate_cache[gate] = (status, now + _gate_cache_ttl)
    return status


def set_gate_status(gate, enabled):
    with PooledConn() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO gate_status (gate, is_enabled) VALUES (?, ?)
            ON CONFLICT (gate) DO UPDATE SET
                is_enabled = excluded.is_enabled,
                updated_at = CURRENT_TIMESTAMP
        """, (gate, 1 if enabled else 0))
        conn.commit()
    _gate_cache[gate] = (enabled, time.monotonic() + _gate_cache_ttl)


ensure_users_table()
ensure_stats_columns()
ensure_proxy_table()
ensure_gate_table()
'''

with open("database.py", "w", encoding="utf-8") as f:
    f.write(NEW_DATABASE)

print("✅ database.py rewritten — now routes through psycopg2 shim")