"""psycopg2.pool shim."""
import threading
from . import connect, Error


class PoolError(Error):
    pass


class AbstractConnectionPool:
    pass


class ThreadedConnectionPool(AbstractConnectionPool):
    def __init__(self, minconn, maxconn, **kwargs):
        self._kwargs = kwargs
        self._max = maxconn
        self._min = minconn
        self._pool = [connect(**kwargs) for _ in range(minconn)]
        self._lock = threading.Lock()

    def getconn(self):
        with self._lock:
            while self._pool:
                c = self._pool.pop()
                if not getattr(c, "closed", False):
                    return c
        return connect(**self._kwargs)

    def putconn(self, conn, key=None, close=False):
        if close:
            try: conn.close()
            except Exception: pass
            return
        if getattr(conn, "closed", False):
            return
        with self._lock:
            if len(self._pool) < self._max:
                self._pool.append(conn)
                return
        try: conn.close()
        except Exception: pass

    def closeall(self):
        with self._lock:
            for c in self._pool:
                try: c.close()
                except Exception: pass
            self._pool = []


class SimpleConnectionPool(ThreadedConnectionPool):
    pass
