"""psycopg2.extras shim."""


class RealDictCursor:
    """Marker class — passing this to cursor() enables dict-style rows."""
    pass


class DictCursor(RealDictCursor):
    pass


class RealDictRow(dict):
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


def execute_batch(cur, sql, argslist, page_size=100):
    cur.executemany(sql, argslist)