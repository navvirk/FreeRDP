import requests
from urllib.parse import quote

# Test 1: Jaisa tumhare paas hai
username = "resi_9a52b873"          # <-- prefix check karo
password = "G9hsU2=PmPoc"
endpoint = "pr.oxylabs.io:7777"

# Test 2: Prefix ke saath (ye sahi format hai)
username_fixed = "customer-resi_9a52b873"

proxies = {
    "http":  f"http://{quote(username_fixed, safe='')}:{quote(password, safe='')}@{endpoint}",
    "https": f"http://{quote(username_fixed, safe='')}:{quote(password, safe='')}@{endpoint}",
}

try:
    r = requests.get("https://ip.oxylabs.io/location", proxies=proxies, timeout=30, verify=False)
    print("Status:", r.status_code)
    print("Body:", r.text[:200])
except Exception as e:
    print("Error:", e)